r"""
[TEST] EARF Inconsistency Checks — checks the 2026 EA GeoPackage and the Preliminary EARF spreadsheet,
cross-checked against the 2024 POPCEN Estimated Number of Households worksheet, and writes the two
"EA List of Inconsistencies" workbooks (GPKG and EARF).

Inputs (one dropdown each, picked from the layers loaded in the Layers panel; all three required):
  EA GeoPackage            <citymun>_ea2026.gpkg layers (attributes only, unsaved edits included)
  Preliminary EARF         spreadsheet layers (*.xlsx sheet, e.g. "EA2026")
  Est. No. of Households   spreadsheet layer of the 2024 POPCEN worksheet

Spreadsheets are re-read from their file with their real header row (QGIS's own spreadsheet reader
does not understand the multi-row EARF header).

Checks (same validation_id in both workbooks unless noted):
  dup_ea          two or more records with every attribute identical (feature id / Excel row ignored)
  dup_geom        GPKG workbook: two or more EAs with the same geometry (normalized)
  dup_new_ean     the same New EA Code is used twice in one barangay (Merged EAs excepted)
  missing_geo     GPKG workbook: household-worksheet geocodes not in the GeoPackage (Merged excepted)
  earf_missing_geo EARF workbook: household-worksheet geocodes not in the EARF (EARF's city/muns only)
  inv_ea_type     EA Type other than Retained, Delineated, Merged
  inv_hhcount     Household count equal to building count
  inv_new_ean     New EA Code that is not 6 digits
  inv_sy          Retained must be 2024; Delineated / Merged must be 2026
  null_ea_count   EA count blank (EARF: only the first row of each old EA; split rows leave it blank)
  null_ea_type / null_hhcount / null_sy   blank values
  null_new_ean    Delineated or Merged EA without a New EA Code
  null_remarks    EA flagged for delineation/merging in the household worksheet, kept Retained, with no
                  remarks in the GeoPackage or WITH remarks in the EARF

Fixes (the template's "Recommended Action"; plan_fixes / apply_earf_fixes), only for the
validation_ids ticked in the results table:
  dup_ea          extra copies deleted (first record kept)
  dup_geom        later same-geometry EAs deleted (first kept; GeoPackage only)
  inv_ea_type     set to Retained
  inv_sy/null_sy  Source Year from the EA Type (after inv_ea_type)
  inv_hhcount/null_hhcount  hh_count = sum of est_hhcount of the building points in the EA
  null_new_ean    Delineated EAs renumbered by the EADM rule (Merged: flag only)
  dup_new_ean     later records renumbered by the EADM rule (first kept)
  the others are flag only. GeoPackage fixes go to the layer's edit buffer; EARF fixes to a copy.

The engine (everything above the "window" section) has no Qt code and can be run headless.
"""
# Menu / panel entry (read by the GMD CO Processing plugin)
TOOL_NAME = "[TEST] EARF Inconsistency Checks"
TOOL_GROUP = "[TEST] EA Post-Processing"
TOOL_ICON = "icons/earf_inconsistency.svg"

import math
import os
import re
import sys
import time
import traceback
from datetime import datetime

import pandas as pd

# ═════════════════════════════ configuration ═════════════════════════════
VALID_TYPES = ("RETAINED", "DELINEATED", "MERGED")
EXPECTED_SY = {"RETAINED": "2024", "DELINEATED": "2026", "MERGED": "2026"}
TRUTHY = {"1", "Y", "YES", "TRUE", "X", "✓", "✔"}
BLANKS = {"", "nan", "none", "null", "<na>", "nat"}
SPREADSHEET_EXT = (".xlsx", ".xlsm", ".xls", ".ods", ".csv")

# (validation_id, title, description) — order and wording follow the templates
CHECKS = [
    ("dup_ea", "Duplicate EA Records", "EAs with duplicate attribute"),
    ("dup_geom", "Duplicate Geometry", "EAs with duplicate geometry"),
    ("dup_new_ean", "Duplicate New EA Code",
     "Multiple records share the same New EA Code where uniqueness is expected"),
    ("missing_geo", "Missing Geocode Match",
     "Geocodes present in the 2024 POPCEN Estimated Number of Households that are not present in the "
     "GeoPackage (Merged EAs excepted)"),
    ("earf_missing_geo", "Missing Geocode Match",
     "Geocodes present in the 2024 POPCEN Estimated Number of Households that are not present in the Prelim EARF "
     "(Merged EAs excepted)"),
    ("inv_ea_type", "Invalid EA Type", "Entries with values other than Retained, Delineated, and Merged"),
    ("inv_hhcount", "Invalid Household Count", "Household count is equal to building count"),
    ("inv_new_ean", "Invalid New EA Code", "Entries with values other than the required 6-digit EA code"),
    ("inv_sy", "Inconsistent EA Type and Source Year",
     "Mismatch between EA Type and SY (Delineated/Merged = 2026, \nRetained = 2024)"),
    ("null_ea_count", "Missing EA Count", "EA count should not be Null"),
    ("null_ea_type", "Missing EA Type", "EA Type is blank or null"),
    ("null_hhcount", "Missing Household Count", "Household count is blank or null"),
    ("null_new_ean", "Missing New EA Code", "Delineated or Merged EAs with missing New EA Code values"),
    ("null_remarks", "Missing Remarks",
     "EAs subject to Delineation/Merging with a Retained EA Type but without corresponding remarks"),
    ("null_sy", "Missing Source Year", "Source Year is blank or null"),
]
CHECK_INFO = {c[0]: c for c in CHECKS}

# validation_id -> (Recommended Action as in the template, what the tool does automatically or None)
SY_ACTION = "Delineated/Merged = 2026, \nRetained = 2024\n\nFix inv_ea_type first before fixing this"
HH_ACTION = "Fill missing hh_count, count est_hhcount from bldg_point layer"
ACTIONS = {
    "dup_ea": ("De-dup", "deletes the extra copies (the first record is kept)"),
    "dup_geom": ("De-dup", "deletes the later EAs with the same geometry (the first is kept)"),
    "dup_new_ean": ("De-dup", "renumbers the later records by the EADM rule (the first is kept)"),
    "missing_geo": ("Match geocode, output list", None),
    "earf_missing_geo": ("Match geocode, output list", None),
    "inv_ea_type": ("Values other than Retained, Delineated, and Merged will be assigned as Retained",
                    "sets EA Type to Retained"),
    "inv_hhcount": (HH_ACTION, "sets hh_count to the sum of est_hhcount of the building points in the EA"),
    "inv_new_ean": ("Renumber (flag only)", None),
    "inv_sy": (SY_ACTION, "sets Source Year from the EA Type (after the EA Type fix)"),
    "null_ea_count": ("(flag only) indicator for dedup", None),
    "null_ea_type": ("(flag only)", None),
    "null_hhcount": ("(flag only) " + HH_ACTION,
                     "sets hh_count to the sum of est_hhcount of the building points in the EA"),
    "null_new_ean": ("Renumber using EADM protocol",
                     "renumbers Delineated EAs by the EADM rule (Merged EAs stay flagged)"),
    "null_remarks": ("(flag only)", None),
    "null_sy": (SY_ACTION, "sets Source Year from the EA Type (after the EA Type fix)"),
}
GPKG_IDS = [c[0] for c in CHECKS if c[0] != "earf_missing_geo"]
EARF_IDS = [c[0] for c in CHECKS if c[0] not in ("missing_geo", "dup_geom")]
TABS = {"gpkg": "GeoPackage", "earf": "prelim EARF"}
CROSS_TABS = {("gpkg", "missing_geo"): "2024 POPCEN and GeoPackage",
              ("earf", "earf_missing_geo"): "2024 POPCEN and Prelim EARF"}

# Value column(s) of each sheet: (internal column, GPKG header, EARF header)
VALUE_COLS = {
    "dup_ea": [],
    "dup_geom": [("ean", "ean", "EA"), ("new_ean", "new_ean", "New EA Code"), ("ea_type", "ea_type", "EA Type")],
    "dup_new_ean": [("new_ean", "new_ean", "New EA Code")],
    "missing_geo": [],
    "earf_missing_geo": [],
    "inv_ea_type": [("ea_type", "ea_type", "EA Type")],
    "inv_hhcount": [("hh_count", "hh_count", "Household\nCount"), ("bldg_count", "bldg_count", "Building\nCount")],
    "inv_new_ean": [("new_ean", "new_ean", "New EA Code")],
    "inv_sy": [("ea_type", "ea_type", "EA Type"), ("sy", "sy", "Source Year")],
    "null_ea_count": [("ea_count", "eacount", "Number of EAs")],
    "null_ea_type": [("ea_type", "ea_type", "EA Type")],
    "null_hhcount": [("hh_count", "hh_count", "Household Count")],
    "null_new_ean": [("new_ean", "new_ean", "New EA Code")],
    "null_remarks": [],
    "null_sy": [("sy", "sy", "Source Year")],
}
GPKG_ID_COLS = [("geocode", "geocode"), ("region", "region"), ("province", "province"),
                ("city_mun", "city_mun"), ("barangay", "barangay")]
EARF_ID_COLS = [("geocode", "Geocode"), ("prov", "Prov"), ("mun", "Mun"), ("brgy", "Brgy"), ("ea", "EA")]


# ═════════════════════════════ small helpers ═════════════════════════════
def norm(name):
    """Header -> key: 'New Enumeration\\nArea Code' -> 'new_enumeration_area_code'."""
    return re.sub(r"[^a-z0-9]+", "_", str(name).lower()).strip("_")


def clean(series):
    """Text values, trimmed, blanks as '', '2026.0' -> '2026'."""
    s = series.astype(object).where(series.notna(), "").astype(str).str.strip()
    s = s.where(~s.str.lower().isin(BLANKS), "")
    return s.str.replace(r"^(-?\d+)\.0+$", r"\1", regex=True)


def code(series, width):
    """Zero-padded code segment; non-numeric values are kept as typed."""
    s = clean(series)
    return s.where(~s.str.isdigit(), s.str.zfill(width))


def pick(columns, *candidates, contains=None):
    """First column whose normalised name is one of candidates (or contains a fragment)."""
    keys = {norm(c): c for c in columns}
    for cand in candidates:
        if cand in keys:
            return keys[cand]
    for frag in (contains or ()):
        for k, c in keys.items():
            if frag in k:
                return c
    return None


ROWKEY_SKIP = {"fid", "_fid", "_layer_id", "_row", "geom", "geometry"}


def row_key(df):
    """All attribute values of a record joined into one key (feature id / Excel row number left out)."""
    keep = [c for c in df.columns if norm(c) not in ROWKEY_SKIP and not str(c).startswith("_")]
    if not keep:
        return pd.Series("", index=df.index)
    parts = [clean(df[c]) for c in keep]
    key = parts[0]
    for p in parts[1:]:
        key = key + "\x1f" + p
    return key


def col(df, name):
    return clean(df[name]) if name and name in df.columns else pd.Series("", index=df.index)


def split_source(source):
    """'C:/x.xlsx|layername=EA2026' -> ('C:/x.xlsx', 'EA2026')."""
    parts = str(source).split("|")
    path, sheet = parts[0], None
    for p in parts[1:]:
        if p.lower().startswith("layername="):
            sheet = p.split("=", 1)[1]
    return path, sheet


def resolve_vrt(path, sheet=None):
    """A .vrt (written by the Spreadsheet Layers plugin) -> the spreadsheet and sheet it points at.

    Any other path is returned unchanged.
    """
    if not str(path).lower().endswith(".vrt") or not os.path.isfile(path):
        return path, sheet
    try:
        import xml.etree.ElementTree as ET
        root = ET.parse(path).getroot()
        layer = root.find("OGRVRTLayer") if root.tag != "OGRVRTLayer" else root
        if sheet:   # a .vrt can hold several layers: take the one named like the QGIS layer
            layer = next((l for l in root.iter("OGRVRTLayer") if l.get("name") == sheet), layer)
        src = layer.find("SrcDataSource")
        src_path = (src.text or "").strip()
        if src.get("relativeToVRT") == "1" or not os.path.isabs(src_path):
            src_path = os.path.join(os.path.dirname(path), src_path)
        src_layer = layer.findtext("SrcLayer") or None
        if src_layer is None:   # SrcSQL: SELECT ... FROM 'Sheet1' / "Sheet1" / Sheet1
            m = re.search(r"\bFROM\s+(?:'([^']+)'|\"([^\"]+)\"|\[([^\]]+)\]|(\S+))",
                          layer.findtext("SrcSQL") or "", re.I)
            src_layer = next((g for g in m.groups() if g), None) if m else None
        return os.path.normpath(src_path), src_layer
    except Exception:
        return path, sheet


def read_sheet_raw(path, sheet=None, nrows=None):
    if path.lower().endswith(".csv"):
        return pd.read_csv(path, header=None, dtype=str, nrows=nrows, keep_default_na=False)
    return pd.read_excel(path, sheet_name=sheet if sheet else 0, header=None, dtype=object, nrows=nrows)


def find_header(raw, required, scan=40):
    """Index of the first row whose normalised cells contain every required key."""
    for i in range(min(scan, len(raw))):
        keys = {norm(v) for v in raw.iloc[i].tolist() if pd.notna(v)}
        if all(any(k == r or k.startswith(r) for k in keys) for r in required):
            return i
    return None


def frame_from(raw, header_idx, fallback_idx=None):
    names = []
    for j, v in enumerate(raw.iloc[header_idx].tolist()):
        name = str(v).strip() if pd.notna(v) and str(v).strip() else ""
        if not name and fallback_idx is not None:
            alt = raw.iloc[fallback_idx, j]
            name = str(alt).strip() if pd.notna(alt) else ""
        base = name or f"col_{j + 1}"
        while base in names:          # keep repeated headers apart
            base += "_"
        names.append(base)
    body = raw.iloc[header_idx + 1:].copy()
    body.columns = names
    body["_row"] = body.index + 1          # Excel row number, for the user
    return body


# ═════════════════════════════ readers ═════════════════════════════
def read_earf(path, sheet=None, label=""):
    """Preliminary EARF -> one row per EA record (barangay / city / province title rows dropped)."""
    raw = read_sheet_raw(path, sheet)
    h = find_header(raw, ["prov", "mun", "brgy", "ea"])
    if h is None:
        raise ValueError(f"{label or path}: no 'Prov / Mun / Brgy / EA' header row found")
    df = frame_from(raw, h)
    # drop the '(2) (3) (4) ...' column-number row
    first = clean(df.iloc[:, 0])
    df = df[~first.str.fullmatch(r"\(\d+\)")]
    c = earf_colmap(df.columns)
    out = pd.DataFrame({
        "prov": code(df[c["prov"]], 3), "mun": code(df[c["mun"]], 2),
        "brgy": code(df[c["brgy"]], 3), "ea": code(df[c["ea"]], 6),
    }, index=df.index)
    out["_rowkey"] = row_key(df)
    for k in ("ea_count", "new_ean", "hh_count", "bldg_count", "ea_type", "sy", "remarks"):
        out[k] = col(df, c[k])
    out["_ea_type_raw"] = out["ea_type"]
    out["_path"], out["_sheet"], out["_xrow"] = path, sheet, df["_row"]
    return _earf_rows(out, df, c, path, label)


def earf_colmap(cols):
    """EARF header names -> {internal field: column name (or None)}."""
    return {
        "prov": pick(cols, "prov", "province_code"),
        "mun": pick(cols, "mun", "city_mun_code"),
        "brgy": pick(cols, "brgy", "barangay_code"),
        "ea": pick(cols, "ea", "ean"),
        "ea_count": pick(cols, "number_of_eas", "no_of_eas", "eacount", contains=["number_of_ea"]),
        "name": pick(cols, contains=["province_city", "barangay_and_ea", "name"]),
        "new_ean": pick(cols, "new_enumeration_area_code", "new_ea_code", "new_ean",
                        contains=["new_enumeration", "new_ea"]),
        "hh_count": pick(cols, "household_count", "hh_count"),
        "bldg_count": pick(cols, "building_count", "bldg_count"),
        "ea_type": pick(cols, "ea_type", "type"),
        "sy": pick(cols, "source_year", "sy", contains=["source_y"]),
        "remarks": pick(cols, "remarks", contains=["remark"]),
    }


def earf_columns(path, sheet=None):
    """{internal field: 1-based Excel column} of an EARF sheet."""
    raw = read_sheet_raw(path, sheet, nrows=60)
    h = find_header(raw, ["prov", "mun", "brgy", "ea"])
    if h is None:
        raise ValueError(f"{path}: no 'Prov / Mun / Brgy / EA' header row found")
    names = list(frame_from(raw.iloc[:h + 1], h).columns)
    return {k: names.index(v) + 1 for k, v in earf_colmap(names).items() if v}


def _earf_rows(out, df, c, path, label):
    out["new_ean"] = out["new_ean"].where(~out["new_ean"].str.isdigit(), out["new_ean"].str.zfill(6))
    out["ea_type"] = out["ea_type"].str.upper()
    name = col(df, c["name"])
    out = out[(out["prov"] != "") | (name != "")]

    name = name.loc[out.index]
    if c["name"]:
        is_ea = name.str.match(r"(?i)^EA\b")
    else:   # no name column: an EA row has some 2026 value
        is_ea = (out["brgy"] != "000") & (out[["new_ean", "ea_type", "hh_count", "sy"]] != "").any(axis=1)

    # names from the title rows: province (mun 00), city/mun (brgy 000), barangay
    titles = out[~is_ea].assign(name=name[~is_ea])
    prov_names = titles[titles["mun"] == "00"].drop_duplicates("prov").set_index("prov")["name"]
    mun_t = titles[(titles["mun"] != "00") & (titles["brgy"] == "000")]
    mun_names = mun_t.assign(k=mun_t["prov"] + mun_t["mun"]).drop_duplicates("k").set_index("k")["name"]
    bgy_t = titles[titles["brgy"] != "000"]
    bgy_names = bgy_t.assign(k=bgy_t["prov"] + bgy_t["mun"] + bgy_t["brgy"]).drop_duplicates("k") \
        .set_index("k")["name"]

    out = out[is_ea].copy()
    out["mun5"] = out["prov"] + out["mun"]
    out["bgy8"] = out["mun5"] + out["brgy"]
    out["geocode"] = out["bgy8"] + out["ea"]                                   # 2024 (old) EA
    out["final_geocode"] = out["bgy8"] + out["new_ean"].where(out["new_ean"] != "", out["ea"])
    out["region"] = ""
    out["province"] = out["prov"].map(prov_names).fillna("")
    out["city_mun"] = out["mun5"].map(mun_names).fillna("")
    out["barangay"] = out["bgy8"].map(bgy_names).fillna("")
    out["source"] = label or os.path.basename(path)
    out["ref"] = "row " + df.loc[out.index, "_row"].astype(str)
    return out.reset_index(drop=True)


def read_household(path, sheet=None, label=""):
    """2024 POPCEN Estimated Number of Households -> one row per EA."""
    raw = read_sheet_raw(path, sheet)
    h = find_header(raw, ["province_code", "barangay_code"])
    if h is None:
        h = find_header(raw, ["prov", "brgy", "ea"])
    if h is None:
        raise ValueError(f"{label or path}: no 'province_code / barangay_code' header row found")
    df = frame_from(raw, h, fallback_idx=h - 1 if h > 0 else None)
    cols = df.columns
    c = {
        "prov": pick(cols, "province_code", "prov_code", "prov"),
        "mun": pick(cols, "city_mun_code", "mun_code", "mun"),
        "brgy": pick(cols, "barangay_code", "brgy_code", "brgy"),
        "ea": pick(cols, "ean", "ea", "ea_code"),
        "level": pick(cols, contains=["level"]),
        "delin": pick(cols, contains=["delineation"]),
        "merg": pick(cols, contains=["merging", "merge"]),
    }
    missing = [k for k in ("prov", "mun", "brgy", "ea") if not c[k]]
    if missing:
        raise ValueError(f"{label or path}: missing column(s) {', '.join(missing)}")
    out = pd.DataFrame({
        "prov": code(df[c["prov"]], 3), "mun": code(df[c["mun"]], 2),
        "brgy": code(df[c["brgy"]], 3), "ea": code(df[c["ea"]], 6),
    }, index=df.index)
    keep = (out["ea"] != "") & out["prov"].str.isdigit()
    if c["level"]:
        lvl = col(df, c["level"])
        keep &= ~lvl.str.contains(r"^\s*[0-4]\s*[-\u2013]|philippines|region|province|huc|city|"
                                  r"municipality|barangay", case=False, regex=True)
    out["subject"] = ""
    for key, word in (("delin", "delineation"), ("merg", "merging")):
        flag = col(df, c[key]).str.upper().isin(TRUTHY)
        out.loc[flag & (out["subject"] == ""), "subject"] = word
    out = out[keep].copy()
    out["mun5"] = out["prov"] + out["mun"]
    out["bgy8"] = out["mun5"] + out["brgy"]
    out["geocode"] = out["bgy8"] + out["ea"]
    out["source"] = label or os.path.basename(path)
    out["ref"] = "row " + (df.loc[out.index, "_row"]).astype(str)
    return out.drop_duplicates("geocode").reset_index(drop=True)


def gpkg_frame(records, label=""):
    """Rows of GeoPackage attributes (list of dicts or DataFrame) -> checked frame."""
    df = records if isinstance(records, pd.DataFrame) else pd.DataFrame(records)
    c = gpkg_colmap(df.columns)
    return _gpkg_rows(df, c, label)


def gpkg_colmap(cols):
    """GeoPackage field names -> {internal field: field name (or None)}."""
    return {
        "geocode": pick(cols, "geocode", "ea_geocode", "psgc_ea"),
        "region": pick(cols, "region"), "province": pick(cols, "province"),
        "city_mun": pick(cols, "city_mun", "municipality", "citymun"),
        "barangay": pick(cols, "barangay"),
        "ean": pick(cols, "ean", "ea"),
        "new_ean": pick(cols, "new_ean", "new_ea_code"),
        "hh_count": pick(cols, "hh_count"), "bldg_count": pick(cols, "bldg_count"),
        "ea_type": pick(cols, "ea_type"), "sy": pick(cols, "sy", "source_year"),
        "ea_count": pick(cols, "eacount", "ea_count", "number_of_eas"),
        "remarks": pick(cols, "remarks", "remark"),
    }


def _gpkg_rows(df, c, label):
    if not c["geocode"]:
        raise ValueError(f"{label}: the layer has no 'geocode' field")
    out = pd.DataFrame(index=df.index)
    out["_rowkey"] = row_key(df)
    for k, name in c.items():
        out[k] = col(df, name)
    out["_ea_type_raw"] = out["ea_type"]
    out["_geomkey"] = clean(df["_geomkey"]) if "_geomkey" in df.columns else ""
    out["geocode"] = out["geocode"].str.replace(r"\D", "", regex=True)
    out["ean"] = out["ean"].where(~out["ean"].str.isdigit(), out["ean"].str.zfill(6))
    out["new_ean"] = out["new_ean"].where(~out["new_ean"].str.isdigit(), out["new_ean"].str.zfill(6))
    out["ea_type"] = out["ea_type"].str.upper()
    out["mun5"] = out["geocode"].str[:5]
    out["bgy8"] = out["geocode"].str[:8]
    out["final_geocode"] = out["geocode"]
    out["old_geocode"] = out["bgy8"] + out["ean"]
    out["source"] = label
    out["ref"] = ("fid " + df["_fid"].astype(str)) if "_fid" in df.columns else ""
    for k in ("_fid", "_layer_id"):
        out[k] = df[k] if k in df.columns else None
    return out.reset_index(drop=True)


# ═════════════════════════════ checks ═════════════════════════════
def common_checks(df, subject_by_geocode, old_key, first_only_count=False, null_remarks_where=None):
    """The 12 checks shared by the GeoPackage and the EARF. Returns {id: (rows, note Series)}."""
    t, sy, nean = df["ea_type"], df["sy"], df["new_ean"]
    res = {}

    def add(cid, mask, note):
        note = note if isinstance(note, pd.Series) else pd.Series(note, index=df.index)
        res[cid] = (df[mask], note[mask])

    rk = df["_rowkey"]
    dup = rk.duplicated(keep=False)
    group = rk.map({k: i + 1 for i, k in enumerate(rk[dup].unique())})
    add("dup_ea", dup, "identical attributes on " + rk.map(rk.value_counts()).astype(str)
        + " records (group " + group.fillna(0).astype(int).astype(str) + ")")

    key = df["bgy8"] + "|" + nean
    cand = (nean != "") & (t != "MERGED")
    dupn = cand & key.where(cand).duplicated(keep=False) & key.where(cand).notna()
    add("dup_new_ean", dupn, "New EA Code " + nean + " repeated in barangay " + df["bgy8"])

    add("inv_ea_type", (t != "") & ~t.isin(VALID_TYPES), "EA Type '" + t + "' is not Retained/Delineated/Merged")

    hh = pd.to_numeric(df["hh_count"], errors="coerce")
    bl = pd.to_numeric(df["bldg_count"], errors="coerce")
    add("inv_hhcount", hh.notna() & bl.notna() & (hh == bl),
        "household count = building count = " + df["hh_count"] + " (recount)")

    add("inv_new_ean", (nean != "") & ~nean.str.fullmatch(r"\d{6}"), "New EA Code '" + nean + "' is not 6 digits")

    exp = t.map(EXPECTED_SY)
    add("inv_sy", exp.notna() & (sy != "") & (sy != exp.fillna("")),
        t.str.title() + " EA should have SY " + exp.fillna("") + ", found " + sy)

    cnt_scope = ~df[old_key].duplicated(keep="first") if first_only_count else pd.Series(True, index=df.index)
    add("null_ea_count", cnt_scope & (df["ea_count"] == ""), "EA count is blank")
    add("null_ea_type", t == "", "EA Type is blank")
    add("null_hhcount", df["hh_count"] == "", "household count is blank")
    add("null_new_ean", t.isin(("DELINEATED", "MERGED")) & (nean == ""), t.str.title() + " EA without New EA Code")

    if subject_by_geocode is not None:
        subj = df[old_key].map(subject_by_geocode).fillna("")
        if null_remarks_where is None:   # this file only
            where = pd.Series("", index=df.index).where(~((t == "RETAINED") & (df["remarks"] == "")), "this file")
        else:                            # GeoPackage and EARF read together (see run_checks)
            where = df[old_key].map(null_remarks_where).fillna("")
        add("null_remarks", (subj != "") & (where != ""),
            "subject for " + subj + " in the household worksheet; Retained "
            + where.str.replace("GeoPackage", "with no remarks in the GeoPackage")
                   .str.replace("EARF", "with remarks in the EARF"))

    add("null_sy", sy == "", "Source Year is blank")
    return res


def run_checks(gpkg=None, earf=None, household=None, step=print):
    """
    gpkg, earf, household: frames from gpkg_frame / read_earf / read_household (or None).
    Returns {"gpkg": {id: DataFrame}, "earf": {id: DataFrame}, "skipped": {(wb, id): reason}}.
    Each result DataFrame has the template columns + '_note', 'source', 'ref' (+ '_fid', '_layer_id').
    """
    t0 = time.time()
    subject = None
    if household is not None and not household.empty:
        s = household[household["subject"] != ""]
        subject = s.set_index("geocode")["subject"]
    out = {"gpkg": {}, "earf": {}, "skipped": {}}
    # 2024 EAs the GeoPackage marks Merged: absorbed into another EA, so never "missing"
    merged = set()
    if gpkg is not None and not gpkg.empty:
        m = gpkg[gpkg["ea_type"] == "MERGED"]
        merged = set(m["old_geocode"]) | set(m["geocode"])

    # null_remarks reads the 3 files together: an EA the household worksheet marks for delineation /
    # merging is flagged (in both workbooks) when it is Retained with no remarks in the GeoPackage
    # OR in the EARF. 2024 geocode -> "GeoPackage", "EARF" or "GeoPackage, EARF".
    where = None
    if subject is not None:
        hits = {}
        # GeoPackage: Retained with NO remarks; EARF: Retained but WITH remarks (user rule)
        for name, frame, key, blank in (("GeoPackage", gpkg, "old_geocode", True),
                                        ("EARF", earf, "geocode", False)):
            if frame is not None and not frame.empty:
                bad = frame[(frame["ea_type"] == "RETAINED") & ((frame["remarks"] == "") == blank)
                            & frame[key].isin(subject.index)]
                for g in bad[key].unique():
                    hits.setdefault(g, []).append(name)
        where = pd.Series({g: ", ".join(v) for g, v in hits.items()}, dtype=str)

    # geocodes each file has (final or 2024 code), for the missing-geocode remarks
    in_gpkg = (set(gpkg["geocode"]) | set(gpkg["old_geocode"])) if gpkg is not None and not gpkg.empty else None
    in_earf = (set(earf["geocode"]) | set(earf["final_geocode"])) if earf is not None and not earf.empty else None

    if gpkg is not None and not gpkg.empty:
        res = common_checks(gpkg, subject, "old_geocode", null_remarks_where=where)
        # dup_geom: two or more EAs with the same geometry (vertex order / start point ignored)
        gk = gpkg["_geomkey"]
        dg = (gk != "") & gk.duplicated(keep=False)
        grp = gk.map({k: i + 1 for i, k in enumerate(gk[dg].unique())})
        gnote = ("same geometry as " + (gk.map(gk.value_counts()) - 1).astype(str)
                 + " other EA(s) (group " + grp.fillna(0).astype(int).astype(str) + ")")
        res["dup_geom"] = (gpkg[dg], gnote[dg])
        if household is not None and not household.empty:
            # 2024 household-worksheet EAs (GeoPackage's city/muns) with no GeoPackage record, by the
            # final geocode or the 2024 EA code; EAs the GeoPackage marks Merged are not missing.
            scope = household[household["mun5"].isin(set(gpkg["mun5"]))]
            miss = scope[~scope["geocode"].isin(in_gpkg) & ~scope["geocode"].isin(merged)].copy()
            for colname, key in (("region", "mun5"), ("province", "mun5"), ("city_mun", "mun5"),
                                 ("barangay", "bgy8")):
                lut = gpkg[gpkg[colname] != ""].drop_duplicates(key).set_index(key)[colname]
                miss[colname] = miss[key].map(lut).fillna("")
            miss["_fid"], miss["_layer_id"] = None, None
            res["missing_geo"] = (miss, missing_note(miss["geocode"], "GeoPackage", "EARF", in_earf))
        else:
            out["skipped"][("gpkg", "missing_geo")] = "no household worksheet ticked"
        if subject is None:
            out["skipped"][("gpkg", "null_remarks")] = "no household worksheet ticked"
        out["gpkg"] = {cid: _shape(rows, note, cid, "gpkg") for cid, (rows, note) in res.items()}
        step(f"GeoPackage: {len(gpkg)} EAs checked")

    if earf is not None and not earf.empty:
        res = common_checks(earf, subject, "geocode", first_only_count=True, null_remarks_where=where)
        if household is not None and not household.empty:
            scope = household[household["mun5"].isin(set(earf["mun5"]))]
            miss = scope[~scope["geocode"].isin(in_earf) & ~scope["geocode"].isin(merged)].copy()
            res["earf_missing_geo"] = (miss, missing_note(miss["geocode"], "EARF", "GeoPackage", in_gpkg))
        else:
            out["skipped"][("earf", "earf_missing_geo")] = "no household worksheet ticked"
            out["skipped"][("earf", "null_remarks")] = "no household worksheet ticked"
        out["earf"] = {cid: _shape(rows, note, cid, "earf") for cid, (rows, note) in res.items()}
        step(f"Preliminary EARF: {len(earf)} EA rows checked")

    step(f"Checks done in {time.time() - t0:.2f}s")
    return out


def missing_note(geocodes, this, other, other_codes):
    """'02011005003000 missing in the GeoPackage and in the EARF' / '... (found in the EARF)'."""
    def one(g):
        if other_codes is None:
            return f"{g} missing in the {this}"
        if g in other_codes:
            return f"{g} missing in the {this} (found in the {other})"
        return f"{g} missing in the {this} and in the {other}"
    return pd.Series([one(g) for g in geocodes], index=geocodes.index, dtype=object)


def _shape(rows, note, cid, wb):
    ids = GPKG_ID_COLS if wb == "gpkg" else EARF_ID_COLS
    if cid in ("dup_ea",) and wb == "gpkg":
        ids = ids + [("ean", "ean")]
    vals = [(c, g if wb == "gpkg" else e) for c, g, e in VALUE_COLS[cid]]
    if wb == "earf" and cid == "inv_hhcount":
        # geocode as in the Preliminary EARF: Prov+Mun+Brgy+New EA Code (EA when blank)
        ids = [("final_geocode", "Geocode")] + ids[1:]
    data = {}
    for c, header in ids + vals:
        data[header] = rows[c] if c in rows.columns else ""
    data["remarks" if wb == "gpkg" else "Remarks"] = note
    for extra in ("source", "ref", "_fid", "_layer_id", "_xrow"):
        data[extra] = rows[extra] if extra in rows.columns else None
    data["_ea_type"] = rows["ea_type"] if "ea_type" in rows.columns else ""
    data["_rowkey"] = rows["_rowkey"] if "_rowkey" in rows.columns else ""
    first = (ids[0][1])
    return pd.DataFrame(data).sort_values(first, kind="mergesort").reset_index(drop=True)


NEW_EAN_IDS = ("null_new_ean", "dup_new_ean", "inv_new_ean")


def _record_key(rec, wb):
    if wb == "gpkg":
        fid = rec.get("_fid")
        return (rec.get("_layer_id"), int(fid)) if fid is not None and pd.notna(fid) else None
    xr = rec.get("_xrow")   # one EARF file per run: the Excel row is enough
    return int(xr) if xr is not None and pd.notna(xr) else None


def annotate_new_ean(df, cid, wb, plan, ticked=(), applied=False):
    """
    Remarks of a New EA Code sheet with what happened to each record: the old and the new New EA Code and
    the EADM explanation when it is (to be) fixed, or why it is not fixed.
    Returns (annotated copy, mask of the records that are fixed by the plan).
    """
    if df is None or df.empty or cid not in NEW_EAN_IDS:
        return df, pd.Series(False, index=getattr(df, "index", None), dtype=bool)
    rcol = "remarks" if wb == "gpkg" else "Remarks"
    fixes = {}
    if plan is not None and len(plan):
        p = plan[(plan["field"] == "new_ean") & (plan["validation_id"] == cid)]
        for _, r in p.iterrows():
            fixes[_record_key(r, wb)] = r
    out = df.copy()
    copies = out["_rowkey"].map(out["_rowkey"].value_counts()) if "_rowkey" in out.columns else None
    status = "FIXED" if applied else "TO BE FIXED"
    hit = []
    notes = []
    for i, rec in out.iterrows():
        f = fixes.get(_record_key(rec, wb))
        base = rec[rcol] or ""
        if f is not None:
            old = f["old"] or "(blank)"
            notes.append(f"{base}. {status}: new_ean {old} -> {f['new']} ({f['reason']})")
            hit.append(True)
            continue
        hit.append(False)
        if cid == "inv_new_ean":
            why = "not fixed: flag only, renumber manually"
        elif cid == "null_new_ean" and str(rec.get("_ea_type", "")).upper() == "MERGED":
            why = "not fixed: Merged EA, flag only (no numbering rule)"
        elif cid not in ticked:
            why = f"not fixed: {cid} not ticked"
        elif cid == "dup_new_ean" and copies is not None and rec["_rowkey"] != "" and copies[i] > 1:
            why = "not fixed: identical copy of another record (dup_ea); tick dup_ea to delete the copy"
        elif cid == "dup_new_ean":
            why = f"kept: first record with New EA Code {rec.get('new_ean') or rec.get('New EA Code')}"
        else:
            why = "not fixed: the EA code is not 6 digits or no EA number is left"
        notes.append(f"{base}. {why}")
    out[rcol] = notes
    return out, pd.Series(hit, index=out.index, dtype=bool)


def counts(results):
    return {(wb, cid): len(df) for wb in ("gpkg", "earf") for cid, df in results[wb].items()}


# ═════════════════════════════ fixes (Recommended Action) ═════════════════════════════
FIX_COLS = ["validation_id", "action", "field", "old", "new", "reason", "geocode", "source", "ref",
            "_fid", "_layer_id", "_path", "_sheet", "_xrow"]


def _type_style(raw_values):
    """'title' when the file mostly writes 'Retained', else 'upper' ('RETAINED')."""
    valid = [v for v in raw_values if v.upper() in VALID_TYPES]
    title = sum(1 for v in valid if v != v.upper())
    return "title" if valid and title > len(valid) / 2 else "upper"


def _first3(code6):
    return int(code6[:3]) if len(code6) == 6 and code6.isdigit() else None


def plan_fixes(df, wb, hh_sum=None, only=None):
    """
    The template's Recommended Actions as a list of changes; no file is touched.

    df: frame from gpkg_frame / read_earf; wb: 'gpkg' or 'earf'.
    hh_sum: building-point recount (sum of est_hhcount per EA) — GPKG {(layer_id, fid): n},
            EARF {final geocode: n}; None skips the household fixes.
    only: the validation_ids to fix (None = every fixable one). A fix left out is skipped, so the later
          fixes see the unfixed value (e.g. without inv_ea_type an invalid type gets no Source Year).
    Fixes run in order on a working copy, so each sees the earlier ones:
      dup_ea (delete copies) -> inv_ea_type -> inv_sy / null_sy -> inv_hhcount / null_hhcount
      -> null_new_ean (Delineated) -> dup_new_ean.
    EADM numbering: an EA keeps its own (mother) code when that code is free in the barangay; the other
    delineated parts / repeated codes get (highest EA number in the barangay + 1) followed by the mother's 3 digits
    (mother 005000, last EA 009000 -> 010005). A barangay's single EA 000000 splits into 001000, 002000...
    Returns a DataFrame with FIX_COLS.
    """
    changes = []
    if df is None or df.empty:
        return pd.DataFrame(columns=FIX_COLS)
    w = df.copy()
    mother_col = "ean" if wb == "gpkg" else "ea"

    def on(*cids):
        return only is None or any(c in only for c in cids)

    def emit(cid, idx, field, old, new, action="set", reason=""):
        r = w.loc[idx]
        changes.append({"validation_id": cid, "action": action, "field": field, "old": old, "new": new,
                        "reason": reason,
                        "geocode": r["geocode"], "source": r.get("source"), "ref": r.get("ref"),
                        **{k: r.get(k) for k in ("_fid", "_layer_id", "_path", "_sheet", "_xrow")}})

    # dup_ea: keep the first record of each identical group, delete the others
    dup = w["_rowkey"].duplicated(keep="first") & on("dup_ea")
    for idx in w.index[dup]:
        emit("dup_ea", idx, "", "", "", action="delete")
    w = w[~dup].copy()

    # dup_geom (GeoPackage): keep the first EA of each same-geometry group, delete the others
    if wb == "gpkg" and "_geomkey" in w.columns and on("dup_geom"):
        gk = w["_geomkey"]
        dg = (gk != "") & gk.duplicated(keep="first")
        for idx in w.index[dg]:
            emit("dup_geom", idx, "", "", "", action="delete", reason="same geometry as an earlier EA")
        w = w[~dg].copy()

    # inv_ea_type: anything else becomes Retained
    retained = "Retained" if _type_style(w["_ea_type_raw"]) == "title" else "RETAINED"
    t = w["ea_type"]
    for idx in w.index[(t != "") & ~t.isin(VALID_TYPES)] if on("inv_ea_type") else ():
        emit("inv_ea_type", idx, "ea_type", w.at[idx, "_ea_type_raw"], retained)
        w.at[idx, "ea_type"] = "RETAINED"

    # inv_sy / null_sy: Source Year from the (fixed) EA Type; a blank EA Type is left flagged
    exp = w["ea_type"].map(EXPECTED_SY)
    for idx in w.index[exp.notna() & (w["sy"] != exp.fillna(""))]:
        if not on("null_sy" if w.at[idx, "sy"] == "" else "inv_sy"):
            continue
        emit("null_sy" if w.at[idx, "sy"] == "" else "inv_sy", idx, "sy", w.at[idx, "sy"], exp[idx])
        w.at[idx, "sy"] = exp[idx]

    # inv_hhcount / null_hhcount: recount from the building points
    if hh_sum is not None and on("inv_hhcount", "null_hhcount"):
        hh = pd.to_numeric(w["hh_count"], errors="coerce")
        bl = pd.to_numeric(w["bldg_count"], errors="coerce")
        for idx in w.index[(w["hh_count"] == "") | (hh.notna() & bl.notna() & (hh == bl))]:
            if wb == "gpkg":
                fid = w.at[idx, "_fid"]
                key = (w.at[idx, "_layer_id"], int(fid)) if pd.notna(fid) else None
            else:
                key = w.at[idx, "final_geocode"]
            n = hh_sum.get(key)
            if n is None:
                continue
            new, old = str(math.ceil(round(n, 6))), w.at[idx, "hh_count"]   # rounded up: 168.963 -> 169
            if new == old or not on("null_hhcount" if old == "" else "inv_hhcount"):
                continue
            emit("null_hhcount" if old == "" else "inv_hhcount", idx, "hh_count", old, new)
            w.at[idx, "hh_count"] = new

    # renumbering (EADM)
    codes = pd.concat([w[["bgy8", mother_col]].set_axis(["bgy8", "c"], axis=1),
                       w[["bgy8", "new_ean"]].set_axis(["bgy8", "c"], axis=1)])
    last = {}
    for b, cs in codes.groupby("bgy8")["c"]:
        nums = [x for x in map(_first3, cs) if x is not None]
        last[b] = max(nums) if nums else 0
    taken = set(w["bgy8"] + w["new_ean"])

    def renumber(cid, idx, keep_mother):
        b, m = w.at[idx, "bgy8"], w.at[idx, mother_col]
        if not (len(m) == 6 and m.isdigit()):
            return
        if keep_mother and m != "000000" and b + m not in taken:
            new = m
            why = f"EADM: kept its own (mother) EA code {m}, which is not used yet in the barangay"
        else:
            prev = last.get(b, 0)
            last[b] = prev + 1
            if last[b] > 999:
                return
            if m == "000000":
                new = f"{last[b]:03d}000"
                why = (f"EADM: the barangay's single EA 000000 is split; next EA number {last[b]:03d} "
                       f"+ 000 = {new}")
            else:
                new = f"{last[b]:03d}{m[:3]}"
                why = (f"EADM: next EA number after the barangay's last EA ({prev:03d}) is {last[b]:03d}, "
                       f"followed by the mother EA {m[:3]} = {new}")
        emit(cid, idx, "new_ean", w.at[idx, "new_ean"], new, reason=why)
        if wb == "gpkg":   # the GeoPackage geocode is barangay + New EA Code
            emit(cid, idx, "geocode", w.at[idx, "geocode"], b + new, reason="geocode = barangay + New EA Code")
            w.at[idx, "geocode"] = b + new
        taken.add(b + new)
        w.at[idx, "new_ean"] = new

    blank = w[(w["ea_type"] == "DELINEATED") & (w["new_ean"] == "")]
    for idx in blank.sort_values(["bgy8", mother_col], kind="mergesort").index if on("null_new_ean") else ():
        renumber("null_new_ean", idx, True)
    # an identical copy of another record is a dup_ea case (deleted there), not renumbered
    cand = (w["new_ean"] != "") & (w["ea_type"] != "MERGED") & ~w["_rowkey"].duplicated(keep=False)
    key = (w["bgy8"] + "|" + w["new_ean"]).where(cand)
    for idx in w.index[cand & key.duplicated(keep="first")] if on("dup_new_ean") else ():
        renumber("dup_new_ean", idx, True)

    return pd.DataFrame(changes, columns=FIX_COLS)


def fix_counts(plan):
    """{validation_id: number of records fixed} (a renumbered GeoPackage EA counts once)."""
    if plan is None or plan.empty:
        return {}
    p = plan[plan["field"] != "geocode"]
    return p.groupby("validation_id").size().to_dict()


def _typed(new, old, field):
    """The new value in the cell's own type (numbers stay numbers, codes stay text)."""
    if field == "hh_count" or (isinstance(old, (int, float)) and not isinstance(old, bool)
                               and field not in ("new_ean", "ea_type") and str(new).isdigit()):
        return int(new)
    return str(new)


def _delete_row(ws, r):
    """Delete Excel row r and move the merged ranges and row heights below it up."""
    for m in list(ws.merged_cells.ranges):
        if m.min_row <= r <= m.max_row:
            ws.unmerge_cells(str(m))
    heights = {i: d.height for i, d in ws.row_dimensions.items() if i > r}
    ws.delete_rows(r)
    for m in list(ws.merged_cells.ranges):
        if m.min_row > r:
            m.shift(0, -1)
    for i in sorted(heights):
        ws.row_dimensions[i - 1].height = heights[i]
    if heights:
        ws.row_dimensions[max(heights)].height = None


def apply_earf_fixes(plan, out_path):
    """Write the EARF part of a plan into a copy of the EARF workbook. The original is not touched."""
    from openpyxl import load_workbook
    ch = plan[plan["_path"].notna()] if plan is not None else pd.DataFrame()
    if ch.empty:
        return None
    paths = ch["_path"].unique()
    if len(paths) > 1:
        raise ValueError("The EARF fixes span several files; fix one EARF at a time.")
    path = paths[0]
    if not path.lower().endswith((".xlsx", ".xlsm")):
        raise ValueError(f"{os.path.basename(path)}: only .xlsx / .xlsm EARF files can be fixed.")
    same = os.path.normcase(os.path.abspath(out_path)) == os.path.normcase(os.path.abspath(path))
    if same and not os.path.splitext(path)[0].endswith("_fixed"):   # a _fixed copy may be updated again
        raise ValueError("The fixed copy would overwrite the original EARF.")
    book = load_workbook(path, keep_vba=path.lower().endswith(".xlsm"))
    for sheet, part in ch.groupby(ch["_sheet"].fillna(""), sort=False):
        ws = book[sheet] if sheet else book.worksheets[0]
        cols = earf_columns(path, sheet or None)
        for _, r in part[part["action"] == "set"].iterrows():
            if r["field"] not in cols:
                raise ValueError(f"No '{r['field']}' column in the EARF sheet")
            cell = ws.cell(row=int(r["_xrow"]), column=cols[r["field"]])
            cell.value = _typed(r["new"], cell.value, r["field"])
        for xr in sorted(part.loc[part["action"] == "delete", "_xrow"].astype(int).unique(), reverse=True):
            _delete_row(ws, xr)
    book.save(out_path)
    return out_path


def fixed_copy_path(path, folder=None):
    base, ext = os.path.splitext(os.path.basename(path))
    base = re.sub(r"_fixed$", "", base)
    return os.path.join(folder or os.path.dirname(path), f"{base}_fixed{ext}")


# ═════════════════════════════ Excel output ═════════════════════════════
def write_workbook(results, wb_key, path, plan=None, applied=False, ticked=(), fixed_rows=None):
    """Write one 'EA List of Inconsistencies' workbook in the template layout.

    plan: this workbook's fixes (plan_fixes); listed on a 'fixes' sheet and counted on the Summary.
    applied: whether those fixes were already applied (otherwise they are listed as planned).
    ticked: the validation_ids selected for fixing (for the New EA Code remarks).
    fixed_rows: {validation_id: rows already fixed (annotated)}, listed on top of the check's sheet.
    """
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    found = results[wb_key]
    skipped = results.get("skipped", {})
    # checks with no inconsistency are left out (a check that could not run is still listed)
    fixed_rows = fixed_rows or {}
    ids = [cid for cid in (GPKG_IDS if wb_key == "gpkg" else EARF_IDS)
           if (wb_key, cid) in skipped or len(found.get(cid, ())) or len(fixed_rows.get(cid, ()))]
    head_font = Font(bold=True, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="1F4E78")
    zero_fill = PatternFill("solid", fgColor="E2EFDA")
    hit_fill = PatternFill("solid", fgColor="FCE4D6")
    thin = Side(style="thin", color="BFBFBF")
    box = Border(left=thin, right=thin, top=thin, bottom=thin)
    wrap = Alignment(wrap_text=True, vertical="top")

    def header(ws, names, widths):
        for j, (name, w) in enumerate(zip(names, widths), start=2):
            cell = ws.cell(row=3, column=j, value=name)
            cell.font, cell.fill, cell.border = head_font, head_fill, box
            cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
            ws.column_dimensions[get_column_letter(j)].width = w
        ws.column_dimensions["A"].width = 3
        ws.freeze_panes = "B4"

    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = "List of Inconsistencies"
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"] = f"Generated {datetime.now():%Y-%m-%d %H:%M}"
    ws["A2"].font = Font(italic=True, color="7F7F7F")
    fixed = fix_counts(plan)
    status = "fixed" if applied else "to be fixed"
    header(ws, ["validation_id", "tabs", "title", "description", "Recommended Action", "frequency", "remarks"],
           [18, 26, 34, 50, 44, 11, 34])
    for i, cid in enumerate(ids, start=4):
        _, title, desc = CHECK_INFO[cid]
        tab = CROSS_TABS.get((wb_key, cid), TABS[wb_key])
        reason = skipped.get((wb_key, cid))
        n = None if reason else len(found.get(cid, ()))
        if reason:
            note = f"Not checked: {reason}"
        elif ACTIONS[cid][1] is None:
            note = "flag only"
        else:
            note = (f"{fixed[cid]} {status} automatically" if cid in fixed
                    else "not fixed automatically" if plan is not None else "")
        row = [cid, tab, title, desc, ACTIONS[cid][0], n if n is not None else "n/a", note]
        for j, v in enumerate(row, start=2):
            cell = ws.cell(row=i, column=j, value=v)
            cell.border, cell.alignment = box, wrap
        if not reason:
            link = ws.cell(row=i, column=2)
            link.hyperlink = f"#'{cid}'!A1"
            link.font = Font(color="0563C1", underline="single")
        if n is not None:
            ws.cell(row=i, column=7).fill = zero_fill if n == 0 else hit_fill
    if not ids:
        ws["B4"] = "No inconsistencies found."
        ws["B4"].font = Font(bold=True, color="375623")

    for cid in ids:
        if (wb_key, cid) in skipped:
            continue   # not checked: listed on the Summary only
        sh = wb.create_sheet(cid)
        sh["A1"] = CHECK_INFO[cid][1]
        sh["A1"].font = Font(bold=True, size=13)
        sh["B2"] = '=HYPERLINK("#\'Summary\'!A1","< Summary")'
        sh["B2"].font = Font(color="0563C1", underline="single")
        df = found.get(cid)
        if df is None:
            df = _shape(pd.DataFrame(), pd.Series(dtype=str), cid, wb_key)
            if (wb_key, cid) in skipped:
                sh["D2"] = f"Not checked: {skipped[(wb_key, cid)]}"
        if cid in NEW_EAN_IDS:
            df, _ = annotate_new_ean(df, cid, wb_key, plan, ticked, applied)
            if len(fixed_rows.get(cid, ())):
                df = pd.concat([fixed_rows[cid], df], ignore_index=True)
                key = ["_layer_id", "_fid"] if wb_key == "gpkg" else ["_xrow"]
                known = df[key].notna().all(axis=1)
                df = df[~(known & df[key].astype(str).duplicated(keep="first"))]   # a record listed once
        cols = [c for c in df.columns if c not in ("source", "ref") and not str(c).startswith("_")]
        widths = [18 if i == 0 else (40 if c.lower() == "remarks" else 16) for i, c in enumerate(cols)]
        header(sh, cols, widths)
        for r, values in enumerate(df[cols].itertuples(index=False, name=None), start=4):
            for j, v in enumerate(values, start=2):
                cell = sh.cell(row=r, column=j, value=None if v is None or v == "" else str(v))
                cell.border = box
                cell.number_format = "@"
        if len(df):
            sh.auto_filter.ref = f"B3:{get_column_letter(len(cols) + 1)}{len(df) + 3}"

    if plan is not None and len(plan):
        sh = wb.create_sheet("fixes")
        sh["A1"] = "Automatic fixes (" + status + ")"
        sh["A1"].font = Font(bold=True, size=13)
        sh["B2"] = '=HYPERLINK("#\'Summary\'!A1","< Summary")'
        sh["B2"].font = Font(color="0563C1", underline="single")
        names = ["validation_id", "geocode", "action", "field", "old value", "new value", "ref", "explanation"]
        header(sh, names, [18, 18, 10, 14, 18, 18, 14, 60])
        for r, rec in enumerate(plan.itertuples(index=False), start=4):
            vals = [rec.validation_id, rec.geocode, rec.action, rec.field, rec.old, rec.new, rec.ref, rec.reason]
            for j, v in enumerate(vals, start=2):
                cell = sh.cell(row=r, column=j, value=None if v is None or v == "" else str(v))
                cell.border, cell.number_format = box, "@"
        sh.auto_filter.ref = f"B3:I{len(plan) + 3}"
    wb.save(path)
    return path


def output_prefix(frames):
    """City/mun code(s) of the data: '02011', or '020' for a province, or 'combined'."""
    mun = set()
    for f in frames:
        if f is not None and not f.empty:
            mun |= set(f["mun5"][f["mun5"].str.len() == 5])
    if len(mun) == 1:
        return mun.pop()
    provs = {m[:3] for m in mun}
    return provs.pop() if len(provs) == 1 else "combined"


# ═════════════════════════════ window ═════════════════════════════
DIALOG_NAME = "EAListOfInconsistenciesTestDialog"
DIALOG_TITLE = "[TEST] EARF Inconsistency Checks"
DIALOG_SUBTITLE = ("Checks the 2026 EA GeoPackage and the Preliminary EARF against the 2024 POPCEN Estimated "
                   "Number of Households, fixes what the Recommended Actions allow, and writes the two List of "
                   "Inconsistencies workbooks.")

THEMES = {
    False: {"title": "#2C3E50", "sub": "#7F8C8D", "hint": "#455a64", "summary": "#37474f",
            "hit": "#fce4d6", "ok": "#e2efda", "skip": "#eceff1",
            "log": "background:#FFFFFF; color:#1F2937; font-family:Consolas,monospace; font-size:11px;"
                   " border:1px solid #BDC3C7;",
            "help": "QTextBrowser { background:#ffffff; color:#1f2937; font-size:12px;"
                    " border:1px solid #d1d5db; border-radius:4px; padding:8px; }"},
    True: {"title": "#ECEFF1", "sub": "#B0BEC5", "hint": "#B0BEC5", "summary": "#ECEFF1",
           "hit": "#5d4037", "ok": "#2e4d34", "skip": "#37474f",
           "log": "background:#1E2327; color:#ECEFF1; font-family:Consolas,monospace; font-size:11px;"
                  " border:1px solid #37474F;",
           "help": "QTextBrowser { background:#263238; color:#ECEFF1; font-size:12px;"
                   " border:1px solid #455A64; border-radius:4px; padding:8px; }"},
}
TAB_STYLE = """
    QTabBar::tab { font-weight:bold; font-size:12px; min-width:180px; padding:10px 24px; margin-right:2px;
                   border-top-left-radius:4px; border-top-right-radius:4px; }
    QTabBar::tab:selected { border-bottom:3px solid #3498DB; }
"""

_CHECK_ROWS = "".join(
    f'<tr><td style="border:1px solid #e5e7eb;"><b>{cid}</b></td>'
    f'<td style="border:1px solid #e5e7eb;">{title}</td>'
    f'<td style="border:1px solid #e5e7eb;">{desc}</td>'
    f'<td style="border:1px solid #e5e7eb;">{ACTIONS[cid][1] or "<i>flag only</i>"}</td></tr>'
    for cid, title, desc in CHECKS)
_CHECK_HEAD = ('<tr><th align="left">validation_id</th><th align="left">Title</th>'
               '<th align="left">Description</th><th align="left">Automatic fix</th></tr>')

HELP_HTML = f"""
<h2>{DIALOG_TITLE}</h2>
<p>This is a <b>test</b> tool. It finds the inconsistencies listed below in the 2026 EA GeoPackage and the
Preliminary EARF, fixes the ones whose <i>Recommended Action</i> can be automated, and writes two workbooks in the <i>EA List of Inconsistencies</i> template:
<code>&lt;code&gt;_EA List of Incons (GPKG).xlsx</code> and <code>&lt;code&gt;_EA List of Incons (EARF).xlsx</code>.</p>

<h3>Quick start</h3>
<ol>
<li>Add the inputs to the QGIS project (drag the <code>_ea2026.gpkg</code> and the spreadsheets into QGIS;
for a spreadsheet pick the sheet, e.g. <code>EA2026</code>).</li>
<li>Choose the <b>EA GeoPackage</b> layer from the dropdown (press <b>Refresh Layers</b> if a layer you
just added is missing).</li>
<li>For <b>Preliminary EARF</b> and <b>Est. No. of Households</b>, the tool searches the GeoPackage's folder
and fills in the spreadsheet whose name matches (<i>earf</i>; <i>household</i>, <i>hh</i>, <i>popcen</i>
or <i>estimated</i>). Otherwise press <b>Browse…</b> (it opens in that folder) or type the path. Then pick
the <b>Sheet</b>. The spreadsheets do not need to be loaded in QGIS. These three inputs are required.</li>
<li>Optional: choose the <b>Building points</b> layer (a point layer with <code>est_hhcount</code>) so the
household counts can be recounted. With <i>(none)</i>, the household checks are flagged only.</li>
<li>Press <b>Run Check</b>. The table on the right shows each check, how many records it found, how many
can be fixed automatically (<b>Auto-fix</b>) and the template's <b>Recommended Action</b>.</li>
<li>Click a check to list its records below. Double-click a GeoPackage record to zoom to the EA.</li>
<li>Nothing is fixed until you choose: tick the <b>Auto-fix</b> box of each validation_id to fix
(GPKG and EARF rows are ticked separately). The <b>Planned Fixes</b> tab lists the changes of the ticked
checks only, with the old and new value. Some fixes depend on others: Source Year is set from the EA Type,
so an invalid EA Type gets a Source Year only when <code>inv_ea_type</code> is ticked too.</li>
<li>Choose the <b>Output folder</b> and press <b>Export Excel</b>. This is required before fixing: the
workbooks keep a record of the records as they were and of the planned fixes. If you press
<b>Apply Selected Fixes</b> without exporting, a popup asks you to export first (<b>Export Excel Now</b>).</li>
<li>Press <b>Apply Selected Fixes</b>. GeoPackage fixes go into the layer's edit session: review them on the map
and in the attribute table, then <b>Save</b> (or <b>Roll Back</b>) the layer edits in QGIS. EARF fixes are
saved to <code>&lt;EARF name&gt;_fixed.xlsx</code> in the output folder; the original is not changed.
The tool then checks again (using the fixed EARF) so only what is left is listed. Export again to record
what is left and the fixes made. The export is asked for once per <b>Run Check</b>: after it, you can fix
one validation_id after another without exporting again.</li>
</ol>

<h3>Inputs</h3>
<ul>
<li><b>EA GeoPackage</b>: needs <code>geocode, region, province, city_mun, barangay, ean, new_ean, ea_type,
hh_count, bldg_count, sy, eacount, remarks</code>. Unsaved edits are included.</li>
<li><b>Preliminary EARF</b>: the sheet with the <i>Prov / Mun / Brgy / EA</i> header. The file is re-read
directly so its two-row header is understood. Barangay title rows are skipped; only rows named
<i>EA ...</i> are checked.</li>
<li><b>Est. No. of Households</b>: the 2024 POPCEN worksheet with <code>province_code,
city_mun_code, barangay_code, ean</code> and the <i>EA Subject for Delineation / Merging</i> columns.
It is required: it gives <code>earf_missing_geo</code> and the subject flags used by <code>null_remarks</code>.</li>
<li><b>Building points</b> (optional): a point layer with an <code>est_hhcount</code> field (e.g.
<code>bldg_point</code>). Used only for the household recount.</li>
</ul>

<h3>Checks</h3>
<table cellspacing="0" cellpadding="4" style="border-collapse:collapse; width:100%;">{_CHECK_HEAD}{_CHECK_ROWS}</table>

<h3>Automatic fixes (Recommended Action)</h3>
<p>Only the ticked validation_ids are fixed. They run in this order, each on the result of the one before:</p>
<ol>
<li><b>dup_ea</b>: the first record of each identical group is kept; the copies are deleted.</li>
<li><b>dup_geom</b> (GeoPackage): the first EA of each same-geometry group is kept; the others are deleted.
Check the attributes of the deleted EAs before saving the layer edits.</li>
<li><b>inv_ea_type</b>: any EA Type other than Retained, Delineated or Merged becomes <b>Retained</b>
(written the way the file writes its types, <i>RETAINED</i> or <i>Retained</i>).</li>
<li><b>inv_sy</b> / <b>null_sy</b>: Source Year from the EA Type: Retained = 2024, Delineated / Merged
= 2026. A blank EA Type is left flagged.</li>
<li><b>inv_hhcount</b> / <b>null_hhcount</b>: <code>hh_count</code> = the sum of <code>est_hhcount</code>
of the building points inside the EA, <b>rounded up</b> to a whole number (168.963 &rarr; 169). A point on a
shared boundary is counted once. The EARF row takes
the sum of the GeoPackage EA with the same final geocode. An EA with no building point is left flagged.</li>
<li><b>null_new_ean</b> (Delineated EAs; Merged EAs stay flagged) and <b>dup_new_ean</b> (the first
record keeps the code; the others are renumbered): the EADM rule. An EA keeps its own (mother) code when
that code is free in the barangay. Otherwise it gets the next EA number after the highest one in the
barangay, followed by the mother's 3 digits: mother <code>005000</code>, last EA <code>009000</code>
&rarr; <code>010005</code>. A barangay's single EA <code>000000</code> splits into <code>001000</code>,
<code>002000</code>, and so on. In the GeoPackage the <code>geocode</code> is updated too (barangay + New
EA Code). A repeated code on an identical copy of another record is not renumbered: it is a
<code>dup_ea</code> case (tick <code>dup_ea</code> to delete the copy).</li>
</ol>
<p><b>New EA Code remarks</b> (<code>null_new_ean</code>, <code>dup_new_ean</code>, <code>inv_new_ean</code>):
the remarks of each record say what happened to it, in the results table and in the exported sheet:</p>
<ul>
<li><i>TO BE FIXED</i> (before applying) or <i>FIXED</i> (after), with the old and the new New EA Code and
the EADM explanation, e.g. <i>FIXED: new_ean (blank) -&gt; 008007 (EADM: next EA number after the
barangay's last EA (007) is 008, followed by the mother EA 007 = 008007)</i>.</li>
<li>Or why it is not fixed: not ticked, Merged EA (no numbering rule), <code>inv_new_ean</code> is flag
only (renumber manually), an identical copy (<code>dup_ea</code>), or <i>kept</i> for the first record of a
repeated code.</li>
</ul>
<p>Exported after <b>Apply Selected Fixes</b>, these sheets still list the records that were fixed (marked
<i>FIXED</i>) above the ones that are left. The <b>fixes</b> sheet and the <b>Planned Fixes</b> tab have an
<i>explanation</i> column too.</p>
<p><code>missing_geo</code>, <code>earf_missing_geo</code>, <code>inv_new_ean</code>,
<code>null_ea_count</code>, <code>null_ea_type</code> and <code>null_remarks</code> are flag only.
The GeoPackage and the EARF are fixed separately, so check that renumbered codes agree in both.</p>

<h3>Rules used</h3>
<ul>
<li><b>Geocode</b>: GeoPackage <code>geocode</code> is the final code (barangay + New EA Code). For the
EARF the final code is Prov+Mun+Brgy+New EA Code (or EA when blank); the sheets list the 2024 code
Prov+Mun+Brgy+EA.</li>
<li><b>dup_ea</b>: two or more records whose attributes are all the same (every field of the attribute
table, or every column of the EARF row). Only the feature id (<code>fid</code>) and the Excel row number
are ignored. The remarks column gives a group number so the copies can be paired.</li>
<li><b>dup_geom</b> (GeoPackage only): two or more EAs with the same geometry, even if their attributes
differ. Vertex order and start point are ignored. The remarks column gives a group number.</li>
<li><b>dup_new_ean</b>: the same New EA Code value on two or more records in one barangay. Merged EAs are not counted, since
merged parts can share the code they merge into.</li>
<li><b>missing_geo</b> (GPKG workbook): household-worksheet geocodes not in the GeoPackage (neither as
<code>geocode</code> nor as barangay + <code>ean</code>), only for the city/municipalities in the GeoPackage.</li>
<li><b>earf_missing_geo</b> (EARF workbook): household-worksheet geocodes not in the EARF, only for the
city/municipalities present in the EARF.</li>
<li>In both missing checks, an EA whose <code>ea_type</code> is <b>Merged</b> in the GeoPackage is not
counted as missing, since it was merged into another EA.</li>
<li>The remarks of both missing checks name the missing geocode and where it is missing, e.g.
<i>02011009000000 missing in the GeoPackage (found in the EARF)</i> or <i>02011009000000 missing in the
GeoPackage and in the EARF</i>.</li>
<li><b>inv_sy</b>: Retained must be 2024; Delineated and Merged must be 2026.</li>
<li><b>inv_hhcount</b> (EARF workbook): the Geocode column is the Preliminary EARF geocode,
Prov+Mun+Brgy+New EA Code (or EA when blank).</li>
<li><b>null_ea_count</b> (EARF): only the first row of each 2024 EA is checked, because split rows leave
<i>Number of EAs</i> blank.</li>
<li><b>null_remarks</b>: reads the 3 files together. The household worksheet marks the EA for delineation
or merging, but the EA is Retained with <b>no</b> remarks in the GeoPackage, <i>or</i> Retained <b>with</b>
remarks in the EARF. An EARF row with no remarks is not flagged. It is listed in both workbooks, and the
remarks column names the file(s) and the reason.</li>
</ul>

<h3>Output</h3>
<p>Each workbook has a <b>Summary</b> sheet (frequency and Recommended Action of each check, with links;
the remarks column says how many records were or will be fixed automatically, <i>not fixed automatically</i> when the check was not ticked, or <i>flag only</i>), one
sheet per <code>validation_id</code> that found something, and a <b>fixes</b> sheet that lists every
automatic change (old and new value). Exported after <b>Apply Selected Fixes</b>, the frequencies are what is left
and the fixes are listed as <i>fixed</i>. Checks with no inconsistency are left out of the
results table and of the workbooks. The <b>remarks</b> column explains the problem. The file name starts with the
city/municipality code (or the province code, or <i>combined</i>).</p>

<h3>Troubleshooting</h3>
<ul>
<li><i>no 'Prov / Mun / Brgy / EA' header row found</i>: the wrong sheet is loaded; add the EARF sheet.</li>
<li><i>the layer has no 'geocode' field</i>: the chosen GeoPackage layer is not an ea2026 layer.</li>
<li>The EA layer is missing from <b>1. EA GeoPackage</b>: it must be a polygon layer with a
<code>geocode</code> (or <code>ea_geocode</code> / <code>psgc_ea</code>) field, in any letter case. With
several polygon layers, a name with <i>ea2026</i> is picked first, then the layer with the most EA fields;
pick another one from the list if needed, or press <b>Refresh Layers</b>.</li>
<li>The table counts are per check; one EA can appear in several checks.</li>
<li>The building-point layer is not in the <b>Building points</b> list: it must be a point layer with an
<code>est_hhcount</code> field.</li>
<li><i>only .xlsx / .xlsm EARF files can be fixed</i>: save the EARF as .xlsx first.</li>
<li><i>Cannot write the fixed EARF</i>: close the <code>_fixed.xlsx</code> in Excel and press
<b>Apply Selected Fixes</b> again.</li>
<li>Fixes in the GeoPackage are lost if the layer edits are rolled back or QGIS is closed without saving.</li>
</ul>
"""


def make_dialog_class():
    from qgis.core import QgsFeatureRequest, QgsMapLayer, QgsProject, QgsWkbTypes
    from qgis.PyQt import QtWidgets
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QBrush, QColor

    def layer_path(layer):
        try:
            from qgis.core import QgsProviderRegistry
            parts = QgsProviderRegistry.instance().decodeUri(layer.providerType(), layer.source())
            if parts.get("path"):
                return resolve_vrt(parts["path"], parts.get("layerName") or None)
        except Exception:
            pass
        return resolve_vrt(*split_source(layer.source()))

    class LayerPicker(QtWidgets.QGroupBox):
        """One dropdown of the matching layers in the Layers panel."""

        def __init__(self, title, accept, hint, parent=None, optional=None, score=None):
            super().__init__(title, parent)
            self.accept, self.hint, self.optional = accept, re.compile(hint, re.I), optional
            self.score = score   # optional ranking for the default choice (highest wins)
            lay = QtWidgets.QVBoxLayout(self)
            self.combo = QtWidgets.QComboBox()
            self.combo.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToMinimumContentsLengthWithIcon)
            self.combo.setMinimumContentsLength(20)
            lay.addWidget(self.combo)

        def refresh(self):
            current = self.combo.currentData()
            self.combo.blockSignals(True)
            self.combo.clear()
            layers = sorted((l for l in QgsProject.instance().mapLayers().values() if self.accept(l)),
                            key=lambda l: l.name().lower())
            off = 0
            if self.optional:
                self.combo.addItem(self.optional, None)
                off = 1
            for layer in layers:
                self.combo.addItem(layer.name(), layer.id())
                self.combo.setItemData(self.combo.count() - 1, layer.source(), Qt.ToolTipRole)
            if not layers and not self.optional:
                self.combo.addItem("(no matching layer in the Layers panel)", None)
            idx = self.combo.findData(current) if current else -1
            if idx < 0:   # first time / layer removed: pick the likeliest layer by name
                if self.score is not None and layers:
                    hit = max(range(len(layers)), key=lambda i: self.score(layers[i]))
                else:
                    hit = next((i for i, l in enumerate(layers)
                                if self.hint.search(l.name() + " " + l.source())), None)
                idx = hit + off if hit is not None else 0
            self.combo.setCurrentIndex(idx)
            self.combo.blockSignals(False)

        def layer(self):
            lid = self.combo.currentData()
            return QgsProject.instance().mapLayer(lid) if lid else None

        def ticked_layers(self):
            lyr = self.layer()
            return [lyr] if lyr is not None else []

    class FilePicker(QtWidgets.QGroupBox):
        """A spreadsheet path (typed, browsed, or found in the GeoPackage's folder) and its sheet."""

        FILTER = "Spreadsheets (*.xlsx *.xlsm *.xls *.ods *.csv);;All files (*)"

        def __init__(self, title, hint, folder_fn, parent=None):
            super().__init__(title, parent)
            self.hint, self.folder_fn = re.compile(hint, re.I), folder_fn
            lay = QtWidgets.QVBoxLayout(self)
            row = QtWidgets.QHBoxLayout()
            self.path = QtWidgets.QLineEdit()
            self.path.setPlaceholderText("Spreadsheet file (.xlsx, .xls, .ods, .csv)")
            self.path.editingFinished.connect(self._load_sheets)
            browse = QtWidgets.QPushButton("Browse…")
            browse.clicked.connect(self.browse)
            row.addWidget(self.path, 1)
            row.addWidget(browse)
            lay.addLayout(row)
            srow = QtWidgets.QHBoxLayout()
            srow.addWidget(QtWidgets.QLabel("Sheet:"))
            self.sheet = QtWidgets.QComboBox()
            srow.addWidget(self.sheet, 1)
            lay.addLayout(srow)
            self._loaded = None

        def folder(self):
            p = self.path.text().strip()
            if p and os.path.isdir(os.path.dirname(p)):
                return os.path.dirname(p)
            return self.folder_fn() or ""

        def browse(self):
            fn, _ = QtWidgets.QFileDialog.getOpenFileName(self, self.title(), self.folder(), self.FILTER)
            if fn:
                self.path.setText(os.path.normpath(fn))
                self._load_sheets()

        def search_folder(self):
            """Fill in the likeliest spreadsheet in the GeoPackage's folder, if none is set yet."""
            if self.path.text().strip():
                return
            folder = self.folder_fn()
            if not folder or not os.path.isdir(folder):
                return
            try:
                files = sorted(f for f in os.listdir(folder)
                               if f.lower().endswith(SPREADSHEET_EXT) and not f.startswith("~$"))
            except OSError:
                return
            match = next((f for f in files if self.hint.search(f)), None)
            if match:
                self.path.setText(os.path.normpath(os.path.join(folder, match)))
                self._load_sheets()

        def _load_sheets(self):
            p = self.path.text().strip().strip('"')
            if p == self._loaded:
                return
            self._loaded = p
            self.sheet.clear()
            if not os.path.isfile(p) or p.lower().endswith(".csv"):
                return
            try:
                with pd.ExcelFile(p) as book:
                    names = list(book.sheet_names)
            except Exception as exc:
                self.sheet.addItem(f"(cannot open: {exc})", None)
                return
            for n in names:
                self.sheet.addItem(n, n)
            idx = next((i for i, n in enumerate(names) if self.hint.search(n)), 0)
            self.sheet.setCurrentIndex(idx)

        def refresh(self):
            self.search_folder()

        def ticked_layers(self):
            """[(path, sheet, label)] or [] — same role as LayerPicker.ticked_layers."""
            self._load_sheets()
            p = self.path.text().strip().strip('"')
            if not p or not os.path.isfile(p):
                return []
            sheet = self.sheet.currentData()
            label = os.path.basename(p) + (f" [{sheet}]" if sheet else "")
            return [(p, sheet, label)]

    def is_gpkg_layer(layer):
        """A polygon layer (or a GeoPackage table of generic GEOMETRY type) with a geocode field in any
        letter case or alias (geocode / ea_geocode / psgc_ea), like the engine's gpkg_colmap."""
        if layer.type() != QgsMapLayer.VectorLayer:
            return False
        if layer.geometryType() not in (QgsWkbTypes.PolygonGeometry, QgsWkbTypes.UnknownGeometry):
            return False
        return gpkg_colmap(layer.fields().names())["geocode"] is not None

    def gpkg_score(layer):
        """Ranks the ea2026 candidates: a name with 'ea2026' first, then layers with more EA fields."""
        c = gpkg_colmap(layer.fields().names())
        named = bool(re.search(r"ea_?2026", layer.name() + " " + layer.source(), re.I))
        return (named, sum(1 for k in ("new_ean", "ea_type", "sy", "hh_count", "ean") if c[k]))

    def bldg_field(layer):
        return pick(layer.fields().names(), "est_hhcount", "est_hh_count", "est_hh", contains=["est_hh"])

    def is_bldg_layer(layer):
        return (layer.type() == QgsMapLayer.VectorLayer
                and layer.geometryType() == QgsWkbTypes.PointGeometry and bldg_field(layer) is not None)

    def field_value(layer, name, value):
        """The plan's text value in the field's type."""
        fld = layer.fields().field(name)
        if fld.isNumeric():
            try:
                return int(value)
            except (TypeError, ValueError):
                return value
        return str(value)

    class Dialog(QtWidgets.QDialog):
        def __init__(self, iface, parent=None):
            super().__init__(parent)
            self.setObjectName(DIALOG_NAME)
            self.setWindowTitle(f"{DIALOG_TITLE} — EA Tools")
            icon = os.path.join(os.path.dirname(os.path.abspath(__file__)), TOOL_ICON) \
                if "__file__" in globals() else ""
            if icon and os.path.exists(icon):
                from qgis.PyQt.QtGui import QIcon
                self.setWindowIcon(QIcon(icon))
            self.setWindowFlags(self.windowFlags() | Qt.WindowMinimizeButtonHint | Qt.WindowMaximizeButtonHint)
            self.setAttribute(Qt.WA_DeleteOnClose, True)
            self.setMinimumSize(900, 620)
            self.resize(1180, 780)
            self.iface = iface
            self.results = None
            self.frames = (None, None, None)
            self.plans = {"gpkg": pd.DataFrame(columns=FIX_COLS), "earf": pd.DataFrame(columns=FIX_COLS)}
            self.applied_plans = None   # the fixes applied since the last Run Check (listed as 'fixed')
            self.selected = set()       # (workbook, validation_id) ticked for fixing
            self.exported = False       # Export Excel done since the last Run Check
            self.applied_ticked = {}    # workbook -> validation_ids applied since the last Run Check
            self.fixed_rows = {}        # workbook -> {validation_id: New EA Code records fixed (annotated)}
            self.fixable = {}           # workbook -> {validation_id: records that can be fixed}
            self.hh_sums = {}
            self.dark = self.palette().color(self.palette().Window).lightness() < 128
            th = THEMES[self.dark]

            root = QtWidgets.QVBoxLayout(self)
            title = QtWidgets.QLabel(DIALOG_TITLE)
            title.setStyleSheet(f"font-size:18px; font-weight:bold; color:{th['title']};")
            sub = QtWidgets.QLabel(DIALOG_SUBTITLE)
            sub.setWordWrap(True)
            sub.setStyleSheet(f"color:{th['sub']};")
            root.addWidget(title)
            root.addWidget(sub)
            tabs = QtWidgets.QTabWidget()
            tabs.setStyleSheet(TAB_STYLE)
            tabs.addTab(self._main_tab(th), "Inconsistency Check")
            help_view = QtWidgets.QTextBrowser()
            help_view.setOpenExternalLinks(True)
            help_view.setStyleSheet(th["help"])
            html = HELP_HTML
            if self.dark:
                for a, b in (("#e5e7eb", "#455A64"),):
                    html = html.replace(a, b)
            help_view.setHtml(html)
            tabs.addTab(help_view, "Help and Information")
            root.addWidget(tabs, 1)
            close_row = QtWidgets.QHBoxLayout()
            close_row.addStretch()
            close = QtWidgets.QPushButton("Close")
            close.setMinimumWidth(100)
            close.clicked.connect(self.close)
            close_row.addWidget(close)
            root.addLayout(close_row)

            self.refresh_layers()
            QgsProject.instance().layersAdded.connect(self.refresh_layers)
            QgsProject.instance().layersRemoved.connect(self.refresh_layers)

        def closeEvent(self, event):
            for sig in (QgsProject.instance().layersAdded, QgsProject.instance().layersRemoved):
                try:
                    sig.disconnect(self.refresh_layers)
                except Exception:
                    pass
            super().closeEvent(event)

        # ───────────── layout ─────────────
        def _main_tab(self, th):
            page = QtWidgets.QWidget()
            lay = QtWidgets.QHBoxLayout(page)

            left = QtWidgets.QWidget()
            left.setFixedWidth(330)
            lv = QtWidgets.QVBoxLayout(left)
            lv.setContentsMargins(0, 0, 0, 0)
            hint = QtWidgets.QLabel("Choose the GeoPackage layer from the Layers panel, then the two "
                                    "spreadsheet files (Browse…, or found in the GeoPackage's folder) "
                                    "and their sheets. All three are required.")
            hint.setWordWrap(True)
            hint.setStyleSheet(f"color:{th['hint']}; font-size:11px;")
            lv.addWidget(hint)
            self.gpkg_list = LayerPicker("1. EA GeoPackage (ea2026)", is_gpkg_layer, r"ea_?2026",
                                        score=gpkg_score)
            self.earf_list = FilePicker("2. Preliminary EARF", r"earf", self._gpkg_folder)
            self.hh_list = FilePicker("3. Est. No. of Households",
                                      r"household|hh|popcen|estimated", self._gpkg_folder)
            self.bldg_list = LayerPicker("4. Building points (household recount)", is_bldg_layer,
                                         r"bldg|build", optional="(none: household counts flagged only)")
            self.gpkg_list.combo.currentIndexChanged.connect(self.refresh_layers)
            for w in (self.gpkg_list, self.earf_list, self.hh_list, self.bldg_list):
                lv.addWidget(w)
            refresh = QtWidgets.QPushButton("Refresh Layers")
            refresh.clicked.connect(self.refresh_layers)
            lv.addWidget(refresh)

            out_box = QtWidgets.QGroupBox("5. Output folder")
            ob = QtWidgets.QHBoxLayout(out_box)
            self.out_edit = QtWidgets.QLineEdit(os.path.join(os.path.expanduser("~"), "Downloads"))
            browse = QtWidgets.QPushButton("…")
            browse.setFixedWidth(30)
            browse.clicked.connect(self.pick_folder)
            ob.addWidget(self.out_edit)
            ob.addWidget(browse)
            lv.addWidget(out_box)

            self.run_btn = QtWidgets.QPushButton("Run Check")
            self.run_btn.setMinimumHeight(34)
            self.run_btn.setStyleSheet("QPushButton { background:#1565c0; color:white; font-weight:bold;"
                                       " border-radius:4px; } QPushButton:disabled { background:#90a4ae; }")
            self.run_btn.clicked.connect(self.run)
            lv.addWidget(self.run_btn)
            self.progress = QtWidgets.QProgressBar()
            self.progress.setRange(0, 1)
            self.progress.setValue(0)
            self.progress.setTextVisible(False)
            self.progress.setMaximumHeight(8)
            lv.addWidget(self.progress)
            lv.addStretch()
            lay.addWidget(left)

            right = QtWidgets.QVBoxLayout()
            self.summary = QtWidgets.QLabel("Choose the three inputs and press Run Check.")
            self.summary.setStyleSheet(f"font-weight:bold; color:{th['summary']};")
            self.summary.setWordWrap(True)
            right.addWidget(self.summary)

            split = QtWidgets.QSplitter(Qt.Vertical)
            self.check_table = QtWidgets.QTableWidget(0, 7)
            self.check_table.setHorizontalHeaderLabels(["Workbook", "validation_id", "Title", "Frequency",
                                                        "Auto-fix", "Recommended Action", "Note"])
            self.check_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
            self.check_table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
            self.check_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
            self.check_table.verticalHeader().setVisible(False)
            self.check_table.horizontalHeader().setStretchLastSection(True)
            self.check_table.itemSelectionChanged.connect(self.show_rows)
            self.check_table.itemChanged.connect(self.fix_ticked)
            split.addWidget(self.check_table)

            lower = QtWidgets.QWidget()
            lw = QtWidgets.QVBoxLayout(lower)
            lw.setContentsMargins(0, 0, 0, 0)
            frow = QtWidgets.QHBoxLayout()
            frow.addWidget(QtWidgets.QLabel("Search:"))
            self.search = QtWidgets.QLineEdit()
            self.search.setPlaceholderText("geocode, barangay, remarks…")
            self.search.textChanged.connect(self.filter_rows)
            frow.addWidget(self.search)
            lw.addLayout(frow)
            self.row_table = QtWidgets.QTableWidget(0, 0)
            self.row_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
            self.row_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
            self.row_table.setAlternatingRowColors(True)
            self.row_table.verticalHeader().setVisible(False)
            self.row_table.horizontalHeader().setStretchLastSection(True)
            self.row_table.cellDoubleClicked.connect(self.zoom_to_row)
            lw.addWidget(self.row_table)
            self.fix_table = QtWidgets.QTableWidget(0, 0)
            self.fix_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
            self.fix_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
            self.fix_table.setAlternatingRowColors(True)
            self.fix_table.verticalHeader().setVisible(False)
            self.fix_table.horizontalHeader().setStretchLastSection(True)
            self.lower_tabs = QtWidgets.QTabWidget()
            self.lower_tabs.addTab(lower, "Records")
            self.lower_tabs.addTab(self.fix_table, "Planned Fixes")
            split.addWidget(self.lower_tabs)
            split.setSizes([260, 380])
            right.addWidget(split, 1)

            act = QtWidgets.QHBoxLayout()
            self.apply_btn = QtWidgets.QPushButton("Apply Selected Fixes")
            self.apply_btn.setEnabled(False)
            self.apply_btn.setToolTip("Fixes only the checks ticked in the Auto-fix column.\n"
                                      "GeoPackage: the fixes go into the layer's edit session (review, then Save "
                                      "or Roll Back in QGIS).\nEARF: a '_fixed' copy is saved in the output "
                                      "folder; the original is not changed.")
            self.apply_btn.setStyleSheet("QPushButton { background:#2e7d32; color:white; font-weight:bold;"
                                         " border-radius:4px; padding:4px 12px; }"
                                         " QPushButton:disabled { background:#90a4ae; }")
            self.apply_btn.clicked.connect(self.apply_fixes)
            act.addWidget(self.apply_btn)
            self.export_btn = QtWidgets.QPushButton("Export Excel")
            self.export_btn.setEnabled(False)
            self.export_btn.clicked.connect(self.export)
            self.open_btn = QtWidgets.QPushButton("Open Output Folder")
            self.open_btn.clicked.connect(self.open_folder)
            act.addWidget(self.export_btn)
            act.addWidget(self.open_btn)
            act.addStretch()
            right.addLayout(act)

            self.log = QtWidgets.QPlainTextEdit()
            self.log.setReadOnly(True)
            self.log.setMaximumHeight(120)
            self.log.setStyleSheet(th["log"])
            right.addWidget(self.log)
            lay.addLayout(right, 1)
            return page

        # ───────────── actions ─────────────
        def say(self, text):
            self.log.appendPlainText(f"[{datetime.now():%H:%M:%S}] {text}")
            QtWidgets.QApplication.processEvents()

        def refresh_layers(self, *_):
            for w in (self.gpkg_list, self.earf_list, self.hh_list, self.bldg_list):
                w.refresh()

        def pick_folder(self):
            d = QtWidgets.QFileDialog.getExistingDirectory(self, "Output folder", self.out_edit.text())
            if d:
                self.out_edit.setText(d)

        def open_folder(self):
            d = self.out_edit.text()
            if os.path.isdir(d):
                os.startfile(d) if sys.platform == "win32" else None

        def _read_gpkg(self, layers):
            frames = []
            import hashlib
            from qgis.core import QgsGeometry
            for layer in layers:
                names = layer.fields().names()
                rows = []
                for f in layer.getFeatures():
                    d = dict(zip(names, f.attributes()))
                    d["_fid"] = f.id()
                    gkey = ""
                    if f.hasGeometry() and not f.geometry().isEmpty():
                        g = QgsGeometry(f.geometry())
                        g.normalize()   # same shape, other vertex order / start point -> same key
                        gkey = hashlib.md5(bytes(g.asWkb())).hexdigest()
                    d["_geomkey"] = gkey
                    rows.append(d)
                df = pd.DataFrame(rows, columns=names + ["_fid", "_geomkey"])
                df["_layer_id"] = layer.id()
                frames.append(gpkg_frame(df, layer.name()))
                self.say(f"  GeoPackage '{layer.name()}': {len(df)} EAs")
            return pd.concat(frames, ignore_index=True) if frames else None

        def _gpkg_folder(self):
            lyr = self.gpkg_list.layer() if hasattr(self, "gpkg_list") else None
            if lyr is None:
                return ""
            path, _ = layer_path(lyr)
            return os.path.dirname(str(path))

        def _read_sheets(self, files, reader, what):
            frames = []
            for path, sheet, label in files:
                frames.append(reader(path, sheet, label))
                self.say(f"  {what} '{label}': {len(frames[-1])} EA rows")
            return pd.concat(frames, ignore_index=True) if frames else None

        def _hh_sums(self, gpkg_layers, bldg):
            """Sum of est_hhcount of the building points in each EA: ({(layer_id, fid): n}, {geocode: n}).

            A point on a shared boundary is counted once, in the first EA found.
            """
            from qgis.core import QgsCoordinateTransform, QgsGeometry, QgsSpatialIndex
            fld = bldg_field(bldg)
            by_fid, by_geo = {}, {}
            for layer in gpkg_layers:
                gname = gpkg_colmap(layer.fields().names())["geocode"]
                index, polys = QgsSpatialIndex(), {}
                for f in layer.getFeatures():
                    if not f.hasGeometry():
                        continue
                    eng = QgsGeometry.createGeometryEngine(f.geometry().constGet())
                    eng.prepareGeometry()
                    polys[f.id()] = (eng, re.sub(r"\D", "", str(f[gname] or "")))
                    index.addFeature(f)
                xf = QgsCoordinateTransform(bldg.crs(), layer.crs(), QgsProject.instance())
                same = bldg.crs() == layer.crs()
                req = QgsFeatureRequest().setSubsetOfAttributes([fld], bldg.fields())
                for p in bldg.getFeatures(req):
                    if not p.hasGeometry():
                        continue
                    try:
                        n = float(p[fld])
                    except (TypeError, ValueError):
                        n = 0.0
                    geom = QgsGeometry(p.geometry())
                    if not same:
                        geom.transform(xf)
                    for fid in index.intersects(geom.boundingBox()):
                        eng, gc = polys[fid]
                        if eng.intersects(geom.constGet()):
                            by_fid[(layer.id(), fid)] = by_fid.get((layer.id(), fid), 0.0) + n
                            by_geo[gc] = by_geo.get(gc, 0.0) + n
                            break
            return by_fid, by_geo

        def run(self, *_, keep_applied=False):
            if not keep_applied:        # a new Run Check must be exported once before fixing; the
                self.exported = False   # automatic re-check after Apply keeps the earlier export
            if not keep_applied:
                self.applied_plans = None
                self.applied_ticked, self.fixed_rows = {}, {}
            g, e, h = (self.gpkg_list.ticked_layers(), self.earf_list.ticked_layers(),
                       self.hh_list.ticked_layers())
            missing = [name for name, lyr in (("EA GeoPackage", g), ("Preliminary EARF", e),
                                              ("Est. No. of Households", h)) if not lyr]
            if missing:
                QtWidgets.QMessageBox.warning(self, DIALOG_TITLE, "Choose an input for: " + ", ".join(missing))
                return
            if (os.path.normcase(e[0][0]), e[0][1]) == (os.path.normcase(h[0][0]), h[0][1]):
                QtWidgets.QMessageBox.warning(self, DIALOG_TITLE,
                                              "The Preliminary EARF and the household worksheet are the same sheet.")
                return
            self.run_btn.setEnabled(False)
            self.progress.setRange(0, 0)
            QtWidgets.QApplication.setOverrideCursor(Qt.WaitCursor)
            t0 = time.time()
            try:
                self.say("Reading inputs…")
                gpkg = self._read_gpkg(g)
                earf = self._read_sheets(e, read_earf, "EARF")
                hh = self._read_sheets(h, read_household, "Households")
                self.frames = (gpkg, earf, hh)
                self.results = run_checks(gpkg, earf, hh, step=self.say)
                by_fid = by_geo = None
                bldg = self.bldg_list.layer()
                if bldg is not None:
                    self.say(f"Recounting households from '{bldg.name()}' ({bldg_field(bldg)})…")
                    by_fid, by_geo = self._hh_sums(g, bldg)
                self.hh_sums = {"gpkg": by_fid, "earf": by_geo}
                # every possible fix, for the Auto-fix counts; nothing is selected yet
                self.fixable = {wb: fix_counts(plan_fixes(f, wb, self.hh_sums[wb]))
                                for wb, f in (("gpkg", gpkg), ("earf", earf))}
                self.selected = set()
                self.replan()
                if bldg is None:
                    self.say("No building points: household counts are flagged only.")
                self.fill_check_table()
                total = sum(counts(self.results).values())
                self.summary.setText(f"{total} inconsistent record(s) found in "
                                     f"{sum(1 for v in counts(self.results).values() if v)} check(s) "
                                     f"— {time.time() - t0:.1f}s. Click a check to list its records; tick "
                                     "Auto-fix for the checks to fix, then press Apply Selected Fixes.")
                self.export_btn.setEnabled(True)
            except Exception as exc:
                self.say(f"ERROR: {exc}")
                self.say(traceback.format_exc())
                QtWidgets.QMessageBox.critical(self, DIALOG_TITLE, str(exc))
            finally:
                QtWidgets.QApplication.restoreOverrideCursor()
                self.progress.setRange(0, 1)
                self.progress.setValue(1)
                self.run_btn.setEnabled(True)

        def fill_check_table(self):
            th = THEMES[self.dark]
            t = self.check_table
            t.blockSignals(True)
            t.setRowCount(0)
            for wb, ids in (("gpkg", GPKG_IDS), ("earf", EARF_IDS)):
                if not self.results[wb]:
                    continue
                for cid in ids:
                    reason = self.results["skipped"].get((wb, cid))
                    n = None if reason else len(self.results[wb].get(cid, ()))
                    if n == 0:
                        continue   # no inconsistency: not listed
                    r = t.rowCount()
                    t.insertRow(r)
                    can = self.fixable.get(wb, {}).get(cid, 0)
                    auto = ("flag only" if ACTIONS[cid][1] is None
                            else f"Fix {can}" if can else "0 (nothing to fix)")
                    vals = ["GPKG" if wb == "gpkg" else "EARF", cid, CHECK_INFO[cid][1],
                            "n/a" if n is None else str(n), auto, ACTIONS[cid][0].replace("\n", " "),
                            f"Not checked: {reason}" if reason else ""]
                    colour = th["skip"] if n is None else (th["ok"] if n == 0 else th["hit"])
                    for c, v in enumerate(vals):
                        it = QtWidgets.QTableWidgetItem(v)
                        it.setData(Qt.UserRole, (wb, cid))
                        it.setBackground(QBrush(QColor(colour)))
                        if c == 5:
                            it.setToolTip(ACTIONS[cid][0] + (f"\n\nAutomatic: {ACTIONS[cid][1]}"
                                                             if ACTIONS[cid][1] else ""))
                        if c == 4 and can and n:
                            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
                            it.setCheckState(Qt.Checked if (wb, cid) in self.selected else Qt.Unchecked)
                            it.setToolTip(f"Tick to fix this check: {ACTIONS[cid][1]}.\nThe count assumes the "
                                          "checks above it are fixed too (e.g. Source Year needs a valid EA "
                                          "Type); the Planned Fixes tab shows what will really change.")
                        else:
                            it.setFlags(it.flags() & ~Qt.ItemIsUserCheckable)
                        t.setItem(r, c, it)
            t.resizeColumnsToContents()
            t.setColumnWidth(5, min(t.columnWidth(5), 320))
            t.blockSignals(False)

        def fix_ticked(self, item):
            if item.column() != 4 or not (item.flags() & Qt.ItemIsUserCheckable):
                return
            key = item.data(Qt.UserRole)
            if item.checkState() == Qt.Checked:
                self.selected.add(key)
            else:
                self.selected.discard(key)
            self.replan()

        def replan(self):
            """Plan only the ticked validation_ids (in the fix order, so the chain stays right)."""
            gpkg, earf, _ = self.frames
            self.plans = {}
            for wb, frame in (("gpkg", gpkg), ("earf", earf)):
                only = {cid for w, cid in self.selected if w == wb}
                self.plans[wb] = (plan_fixes(frame, wb, self.hh_sums.get(wb), only=only) if only
                                  else pd.DataFrame(columns=FIX_COLS))
            n = sum(len(p) for p in self.plans.values())
            self.fill_fix_table()
            if self.results is not None:
                self.show_rows()
            self.apply_btn.setText(f"Apply Selected Fixes ({n})" if n else "Apply Selected Fixes")
            self.apply_btn.setEnabled(n > 0)

        def fill_fix_table(self):
            names = ["Workbook", "validation_id", "geocode", "action", "field", "old value", "new value", "ref",
                     "explanation"]
            rows = [("GPKG" if wb == "gpkg" else "EARF", r.validation_id, r.geocode, r.action, r.field,
                     r.old, r.new, r.ref, r.reason)
                    for wb in ("gpkg", "earf") for r in self.plans[wb].itertuples(index=False)]
            t = self.fix_table
            t.setRowCount(0)
            t.setColumnCount(len(names))
            t.setHorizontalHeaderLabels(names)
            t.setRowCount(len(rows))
            for i, vals in enumerate(rows):
                for c, v in enumerate(vals):
                    t.setItem(i, c, QtWidgets.QTableWidgetItem("" if v is None else str(v)))
            t.resizeColumnsToContents()
            self.lower_tabs.setTabText(1, f"Planned Fixes ({len(rows)})")

        def apply_fixes(self):
            gp, ep = self.plans["gpkg"], self.plans["earf"]
            if gp.empty and ep.empty:
                return
            if not self.exported:
                # keep a record of the inconsistencies (and the planned fixes) before anything changes
                box = QtWidgets.QMessageBox(self)
                box.setIcon(QtWidgets.QMessageBox.Warning)
                box.setWindowTitle(DIALOG_TITLE)
                box.setText("Export the Excel files first.")
                box.setInformativeText("The List of Inconsistencies workbooks must be exported before the fixes "
                                       "are applied, so there is a record of the records as they were and of "
                                       "the planned fixes.")
                export_btn = box.addButton("Export Excel Now", QtWidgets.QMessageBox.AcceptRole)
                box.addButton(QtWidgets.QMessageBox.Cancel)
                box.exec_()
                if box.clickedButton() is not export_btn or not self.export():
                    return
            folder = self.out_edit.text().strip()
            earf_src = ep["_path"].iloc[0] if not ep.empty else None
            earf_out = fixed_copy_path(earf_src, folder or None) if earf_src else None
            msg = []
            if not gp.empty:
                msg.append(f"GeoPackage: {len(gp)} change(s) ({int((gp['action'] == 'delete').sum())} "
                           "deletion(s)) go into the layer's edit session. Review them, then Save or "
                           "Roll Back the edits in QGIS.")
            if earf_out:
                msg.append(f"EARF: {len(ep)} change(s) are saved to a copy:\n{earf_out}\n"
                           "The original EARF is not changed.")
            if QtWidgets.QMessageBox.question(self, DIALOG_TITLE, "\n\n".join(msg) + "\n\nApply the fixes?") \
                    != QtWidgets.QMessageBox.Yes:
                return
            QtWidgets.QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                for lid, part in gp.groupby("_layer_id", sort=False):
                    layer = QgsProject.instance().mapLayer(lid)
                    if layer is None:
                        self.say(f"GeoPackage layer {lid} is no longer loaded; its fixes were skipped.")
                        continue
                    cmap = gpkg_colmap(layer.fields().names())
                    if not layer.isEditable() and not layer.startEditing():
                        raise RuntimeError(f"'{layer.name()}' cannot be edited.")
                    layer.beginEditCommand("EARF inconsistency fixes")
                    try:
                        failed = 0
                        for _, r in part[part["action"] == "set"].iterrows():
                            name = cmap.get(r["field"])
                            idx = layer.fields().indexOf(name) if name else -1
                            if idx < 0 or not layer.changeAttributeValue(
                                    int(r["_fid"]), idx, field_value(layer, name, r["new"])):
                                failed += 1
                        dels = [int(f) for f in part.loc[part["action"] == "delete", "_fid"]]
                        if dels and not layer.deleteFeatures(dels):
                            failed += len(dels)
                        layer.endEditCommand()
                    except Exception:
                        layer.destroyEditCommand()
                        raise
                    layer.triggerRepaint()
                    self.say(f"'{layer.name()}': {len(part) - failed} fix(es) in the edit session"
                             + (f", {failed} could not be applied" if failed else "")
                             + ". Save the layer edits to keep them.")
                if earf_out:
                    os.makedirs(os.path.dirname(earf_out), exist_ok=True)
                    apply_earf_fixes(ep, earf_out)
                    self.say(f"Saved the fixed EARF: {earf_out}")
                    sheet = self.earf_list.sheet.currentData()
                    self.earf_list.path.setText(earf_out)
                    self.earf_list._load_sheets()
                    i = self.earf_list.sheet.findData(sheet)
                    if i >= 0:
                        self.earf_list.sheet.setCurrentIndex(i)
            except PermissionError as exc:
                QtWidgets.QMessageBox.critical(self, DIALOG_TITLE,
                                               f"Cannot write the fixed EARF (is it open in Excel?)\n{exc}")
                return
            except Exception as exc:
                self.say(f"ERROR: {exc}")
                self.say(traceback.format_exc())
                QtWidgets.QMessageBox.critical(self, DIALOG_TITLE, str(exc))
                return
            finally:
                QtWidgets.QApplication.restoreOverrideCursor()
            prev = self.applied_plans or {}
            applied = {wb: pd.concat([prev[wb], p], ignore_index=True) if wb in prev else p
                       for wb, p in self.plans.items()}
            # New EA Code records fixed now: kept (marked FIXED) for the next export
            for wb in ("gpkg", "earf"):
                ticked = self.ticked(wb)
                self.applied_ticked.setdefault(wb, set()).update(ticked)
                for cid in NEW_EAN_IDS:
                    ann, hit = annotate_new_ean(self.results[wb].get(cid), cid, wb, self.plans[wb], ticked,
                                                applied=True)
                    if ann is not None and hit.any():
                        old = self.fixed_rows.setdefault(wb, {}).get(cid)
                        rows = ann[hit].reset_index(drop=True)
                        self.fixed_rows[wb][cid] = rows if old is None else pd.concat([old, rows],
                                                                                      ignore_index=True)
            self.say("Re-checking with the fixes applied…")
            self.run(keep_applied=True)
            self.applied_plans = applied

        def ticked(self, wb):
            return {cid for w, cid in self.selected if w == wb}

        def current_df(self):
            items = self.check_table.selectedItems()
            if not items or self.results is None:
                return None, None
            wb, cid = items[0].data(Qt.UserRole)
            df = self.results[wb].get(cid)
            if cid in NEW_EAN_IDS:   # remarks say whether / how each record is (to be) renumbered
                df, _ = annotate_new_ean(df, cid, wb, self.plans.get(wb), self.ticked(wb))
            return wb, df

        def show_rows(self):
            wb, df = self.current_df()
            t = self.row_table
            t.setRowCount(0)
            if df is None:
                t.setColumnCount(0)
                return
            cols = [c for c in df.columns if not str(c).startswith("_")]
            t.setColumnCount(len(cols))
            t.setHorizontalHeaderLabels([c.replace("\n", " ") for c in cols])
            t.setRowCount(len(df))
            for r, values in enumerate(df[cols].itertuples(index=False, name=None)):
                for c, v in enumerate(values):
                    it = QtWidgets.QTableWidgetItem("" if v is None else str(v))
                    it.setData(Qt.UserRole, r)
                    t.setItem(r, c, it)
            t.resizeColumnsToContents()
            self.filter_rows()

        def filter_rows(self):
            text = self.search.text().strip().lower()
            t = self.row_table
            for r in range(t.rowCount()):
                hit = not text or any(text in (t.item(r, c).text().lower() if t.item(r, c) else "")
                                      for c in range(t.columnCount()))
                t.setRowHidden(r, not hit)

        def zoom_to_row(self, row, _col):
            wb, df = self.current_df()
            if df is None or self.iface is None:
                return
            rec = df.iloc[self.row_table.item(row, 0).data(Qt.UserRole)]
            lid, fid = rec.get("_layer_id"), rec.get("_fid")
            layer = QgsProject.instance().mapLayer(lid) if isinstance(lid, str) else None
            if layer is None or fid is None or pd.isna(fid):
                self.say("This record has no GeoPackage feature to zoom to.")
                return
            layer.selectByIds([int(fid)])
            self.iface.setActiveLayer(layer)
            self.iface.mapCanvas().zoomToSelected(layer)
            self.iface.mapCanvas().flashFeatureIds(layer, [int(fid)])

        def export(self):
            if self.results is None:
                return False
            folder = self.out_edit.text().strip()
            if not folder:
                QtWidgets.QMessageBox.warning(self, DIALOG_TITLE, "Choose the output folder first.")
                return False
            os.makedirs(folder, exist_ok=True)
            prefix = output_prefix(self.frames)
            written = []
            try:
                for wb, label in (("gpkg", "GPKG"), ("earf", "EARF")):
                    if self.results[wb]:
                        path = os.path.join(folder, f"{prefix}_EA List of Incons ({label}).xlsx")
                        if self.applied_plans is not None:
                            write_workbook(self.results, wb, path, self.applied_plans[wb], applied=True,
                                           ticked=self.applied_ticked.get(wb, set()),
                                           fixed_rows=self.fixed_rows.get(wb))
                        else:
                            write_workbook(self.results, wb, path, self.plans[wb], ticked=self.ticked(wb))
                        written.append(path)
                        self.say(f"Saved {path}")
            except PermissionError as exc:
                QtWidgets.QMessageBox.critical(self, DIALOG_TITLE,
                                               f"Cannot write the file (is it open in Excel?)\n{exc}")
                return False
            if written:
                self.exported = True
                QtWidgets.QMessageBox.information(self, DIALOG_TITLE, "Saved:\n" + "\n".join(written))
            return bool(written)

    return Dialog


def show_dialog():
    from qgis.PyQt.QtWidgets import QApplication, QDialog
    try:
        while QApplication.overrideCursor() is not None:
            QApplication.restoreOverrideCursor()
    except Exception:
        pass
    qgis_iface = globals().get("iface")
    if qgis_iface is None:
        try:
            from qgis.utils import iface as qgis_iface
        except ImportError:
            qgis_iface = None
    main = qgis_iface.mainWindow() if qgis_iface is not None else None
    if main is not None:
        for old in main.findChildren(QDialog, DIALOG_NAME):
            old.close()
    dialog = make_dialog_class()(qgis_iface, main)
    dialog.show()
    dialog.raise_()
    dialog.activateWindow()
    return dialog


if "qgis" in sys.modules and not os.environ.get("EA_INCONS_NO_DIALOG"):
    _DIALOG = show_dialog()
elif "qgis" not in sys.modules:
    print(f"Run this script inside QGIS: GMD CO Processing > {TOOL_NAME}.")
